--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lims;
--
-- Name: lims; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE lims WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE lims OWNER TO postgres;

\connect lims

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: lims; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA lims;


ALTER SCHEMA lims OWNER TO postgres;

--
-- Name: SCHEMA lims; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA lims IS 'standard public schema';


--
-- Name: breakpoint; Type: TYPE; Schema: lims; Owner: postgres
--

CREATE TYPE lims.breakpoint AS (
);


ALTER TYPE lims.breakpoint OWNER TO postgres;

--
-- Name: frame; Type: TYPE; Schema: lims; Owner: postgres
--

CREATE TYPE lims.frame AS (
);


ALTER TYPE lims.frame OWNER TO postgres;

--
-- Name: proxyinfo; Type: TYPE; Schema: lims; Owner: postgres
--

CREATE TYPE lims.proxyinfo AS (
);


ALTER TYPE lims.proxyinfo OWNER TO postgres;

--
-- Name: targetinfo; Type: TYPE; Schema: lims; Owner: postgres
--

CREATE TYPE lims.targetinfo AS (
);


ALTER TYPE lims.targetinfo OWNER TO postgres;

--
-- Name: var; Type: TYPE; Schema: lims; Owner: postgres
--

CREATE TYPE lims.var AS (
);


ALTER TYPE lims.var OWNER TO postgres;

--
-- Name: dict_main_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM dict_main WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_del(p_id integer) OWNER TO postgres;

--
-- Name: dict_main_ins(text, text, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_ins(p_name text, p_note text, p_parent_fk integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO dict_main(
	name,
	note,
	parent_fk,
	order_num)
VALUES(
	p_name,
	p_note,
	p_parent_fk,
	p_order_num) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_ins(p_name text, p_note text, p_parent_fk integer, p_order_num integer) OWNER TO postgres;

--
-- Name: dict_main_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE dict_main
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: dict_main_set_note(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_set_note(p_id integer, p_note text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE dict_main
SET note = p_note
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_set_note(p_id integer, p_note text) OWNER TO postgres;

--
-- Name: dict_main_set_order_num(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_set_order_num(p_id integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE dict_main
SET order_num = p_order_num
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_set_order_num(p_id integer, p_order_num integer) OWNER TO postgres;

--
-- Name: dict_main_set_parent_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_set_parent_fk(p_id integer, p_parent_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE dict_main
SET parent_fk = p_parent_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_set_parent_fk(p_id integer, p_parent_fk integer) OWNER TO postgres;

--
-- Name: dict_main_upd(integer, text, text, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.dict_main_upd(p_id integer, p_name text, p_note text, p_parent_fk integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM dict_main_set_name(p_id, p_name);

PERFORM dict_main_set_note(p_id, p_note);

PERFORM dict_main_set_parent_fk(p_id, p_parent_fk);

PERFORM dict_main_set_order_num(p_id, p_order_num);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.dict_main_upd(p_id integer, p_name text, p_note text, p_parent_fk integer, p_order_num integer) OWNER TO postgres;

--
-- Name: meta_attribute_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_attribute WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_attribute_ins(text, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_ins(p_name text, p_caption text, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_attribute(
	name,
	caption,
	type)
VALUES(
	p_name,
	p_caption,
	p_type) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_ins(p_name text, p_caption text, p_type text) OWNER TO postgres;

--
-- Name: meta_attribute_set_caption(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_set_caption(p_id integer, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_attribute
SET caption = p_caption
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_set_caption(p_id integer, p_caption text) OWNER TO postgres;

--
-- Name: meta_attribute_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_attribute
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_attribute_set_type(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_set_type(p_id integer, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_attribute
SET type = p_type
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_set_type(p_id integer, p_type text) OWNER TO postgres;

--
-- Name: meta_attribute_upd(integer, text, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_attribute_upd(p_id integer, p_name text, p_caption text, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_attribute_set_name(p_id, p_name);

PERFORM meta_attribute_set_caption(p_id, p_caption);

PERFORM meta_attribute_set_type(p_id, p_type);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_attribute_upd(p_id integer, p_name text, p_caption text, p_type text) OWNER TO postgres;

--
-- Name: meta_item_attribute_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_item_attribute WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_item_attribute_ins(integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_ins(p_item_fk integer, p_attribute_fk integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_item_attribute(
	item_fk,
	attribute_fk,
	order_num)
VALUES(
	p_item_fk,
	p_attribute_fk,
	p_order_num) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_ins(p_item_fk integer, p_attribute_fk integer, p_order_num integer) OWNER TO postgres;

--
-- Name: meta_item_attribute_set_attribute_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_set_attribute_fk(p_id integer, p_attribute_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item_attribute
SET attribute_fk = p_attribute_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_set_attribute_fk(p_id integer, p_attribute_fk integer) OWNER TO postgres;

--
-- Name: meta_item_attribute_set_item_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_set_item_fk(p_id integer, p_item_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item_attribute
SET item_fk = p_item_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_set_item_fk(p_id integer, p_item_fk integer) OWNER TO postgres;

--
-- Name: meta_item_attribute_set_order_num(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_set_order_num(p_id integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item_attribute
SET order_num = p_order_num
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_set_order_num(p_id integer, p_order_num integer) OWNER TO postgres;

--
-- Name: meta_item_attribute_upd(integer, integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_attribute_upd(p_id integer, p_item_fk integer, p_attribute_fk integer, p_order_num integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_item_attribute_set_item_fk(p_id, p_item_fk);

PERFORM meta_item_attribute_set_attribute_fk(p_id, p_attribute_fk);

PERFORM meta_item_attribute_set_order_num(p_id, p_order_num);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_attribute_upd(p_id integer, p_item_fk integer, p_attribute_fk integer, p_order_num integer) OWNER TO postgres;

--
-- Name: meta_item_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_item WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_item_ins(text, integer, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_ins(p_name text, p_order_attribute_fk integer, p_caption text, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_item(
	name,
	order_attribute_fk,
	caption,
	type)
VALUES(
	p_name,
	p_order_attribute_fk,
	p_caption,
	p_type) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_ins(p_name text, p_order_attribute_fk integer, p_caption text, p_type text) OWNER TO postgres;

--
-- Name: meta_item_set_caption(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_set_caption(p_id integer, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item
SET caption = p_caption
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_set_caption(p_id integer, p_caption text) OWNER TO postgres;

--
-- Name: meta_item_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_item_set_order_attribute_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_set_order_attribute_fk(p_id integer, p_order_attribute_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item
SET order_attribute_fk = p_order_attribute_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_set_order_attribute_fk(p_id integer, p_order_attribute_fk integer) OWNER TO postgres;

--
-- Name: meta_item_set_type(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_set_type(p_id integer, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_item
SET type = p_type
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_set_type(p_id integer, p_type text) OWNER TO postgres;

--
-- Name: meta_item_upd(integer, text, integer, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_item_upd(p_id integer, p_name text, p_order_attribute_fk integer, p_caption text, p_type text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_item_set_name(p_id, p_name);

PERFORM meta_item_set_order_attribute_fk(p_id, p_order_attribute_fk);

PERFORM meta_item_set_caption(p_id, p_caption);

PERFORM meta_item_set_type(p_id, p_type);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_item_upd(p_id integer, p_name text, p_order_attribute_fk integer, p_caption text, p_type text) OWNER TO postgres;

--
-- Name: meta_model_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_model WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_model_ins(text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_ins(p_name text, p_note text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_model(
	name,
	note)
VALUES(
	p_name,
	p_note) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_ins(p_name text, p_note text) OWNER TO postgres;

--
-- Name: meta_model_item_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_item_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_model_item WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_item_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_model_item_ins(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_item_ins(p_model_fk integer, p_item_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_model_item(
	model_fk,
	item_fk)
VALUES(
	p_model_fk,
	p_item_fk) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_item_ins(p_model_fk integer, p_item_fk integer) OWNER TO postgres;

--
-- Name: meta_model_item_set_item_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_item_set_item_fk(p_id integer, p_item_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_model_item
SET item_fk = p_item_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_item_set_item_fk(p_id integer, p_item_fk integer) OWNER TO postgres;

--
-- Name: meta_model_item_set_model_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_item_set_model_fk(p_id integer, p_model_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_model_item
SET model_fk = p_model_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_item_set_model_fk(p_id integer, p_model_fk integer) OWNER TO postgres;

--
-- Name: meta_model_item_upd(integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_item_upd(p_id integer, p_model_fk integer, p_item_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_model_item_set_model_fk(p_id, p_model_fk);

PERFORM meta_model_item_set_item_fk(p_id, p_item_fk);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_item_upd(p_id integer, p_model_fk integer, p_item_fk integer) OWNER TO postgres;

--
-- Name: meta_model_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_model
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_model_set_note(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_set_note(p_id integer, p_note text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_model
SET note = p_note
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_set_note(p_id integer, p_note text) OWNER TO postgres;

--
-- Name: meta_model_upd(integer, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_model_upd(p_id integer, p_name text, p_note text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_model_set_name(p_id, p_name);

PERFORM meta_model_set_note(p_id, p_note);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_model_upd(p_id integer, p_name text, p_note text) OWNER TO postgres;

--
-- Name: meta_module_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_module WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_module_ins(text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_ins(p_name text, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_module(
	name,
	caption)
VALUES(
	p_name,
	p_caption) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_ins(p_name text, p_caption text) OWNER TO postgres;

--
-- Name: meta_module_privilege_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_privilege_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_module_privilege WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_privilege_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_module_privilege_ins(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_privilege_ins(p_module_fk integer, p_privilege_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_module_privilege(
	module_fk,
	privilege_fk)
VALUES(
	p_module_fk,
	p_privilege_fk) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_privilege_ins(p_module_fk integer, p_privilege_fk integer) OWNER TO postgres;

--
-- Name: meta_module_privilege_set_module_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_privilege_set_module_fk(p_id integer, p_module_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_module_privilege
SET module_fk = p_module_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_privilege_set_module_fk(p_id integer, p_module_fk integer) OWNER TO postgres;

--
-- Name: meta_module_privilege_set_privilege_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_privilege_set_privilege_fk(p_id integer, p_privilege_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_module_privilege
SET privilege_fk = p_privilege_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_privilege_set_privilege_fk(p_id integer, p_privilege_fk integer) OWNER TO postgres;

--
-- Name: meta_module_privilege_upd(integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_privilege_upd(p_id integer, p_module_fk integer, p_privilege_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_module_privilege_set_module_fk(p_id, p_module_fk);

PERFORM meta_module_privilege_set_privilege_fk(p_id, p_privilege_fk);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_privilege_upd(p_id integer, p_module_fk integer, p_privilege_fk integer) OWNER TO postgres;

--
-- Name: meta_module_set_caption(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_set_caption(p_id integer, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_module
SET caption = p_caption
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_set_caption(p_id integer, p_caption text) OWNER TO postgres;

--
-- Name: meta_module_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_module
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_module_upd(integer, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_module_upd(p_id integer, p_name text, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_module_set_name(p_id, p_name);

PERFORM meta_module_set_caption(p_id, p_caption);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_module_upd(p_id integer, p_name text, p_caption text) OWNER TO postgres;

--
-- Name: meta_privilege_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_privilege WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_privilege_ins(text, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_ins(p_name text, p_caption text, p_role_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_privilege(
	name,
	caption,
	role_name)
VALUES(
	p_name,
	p_caption,
	p_role_name) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_ins(p_name text, p_caption text, p_role_name text) OWNER TO postgres;

--
-- Name: meta_privilege_set_caption(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_set_caption(p_id integer, p_caption text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_privilege
SET caption = p_caption
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_set_caption(p_id integer, p_caption text) OWNER TO postgres;

--
-- Name: meta_privilege_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_privilege
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_privilege_set_role_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_set_role_name(p_id integer, p_role_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_privilege
SET role_name = p_role_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_set_role_name(p_id integer, p_role_name text) OWNER TO postgres;

--
-- Name: meta_privilege_upd(integer, text, text, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_privilege_upd(p_id integer, p_name text, p_caption text, p_role_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_privilege_set_name(p_id, p_name);

PERFORM meta_privilege_set_caption(p_id, p_caption);

PERFORM meta_privilege_set_role_name(p_id, p_role_name);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_privilege_upd(p_id integer, p_name text, p_caption text, p_role_name text) OWNER TO postgres;

--
-- Name: meta_script_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_script WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_script_ins(integer, text, numeric, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_ins(p_model_fk integer, p_name text, p_version numeric, p_text text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_script(
	model_fk,
	name,
	version,
	text)
VALUES(
	p_model_fk,
	p_name,
	p_version,
	p_text) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_ins(p_model_fk integer, p_name text, p_version numeric, p_text text) OWNER TO postgres;

--
-- Name: meta_script_set_model_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_set_model_fk(p_id integer, p_model_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_script
SET model_fk = p_model_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_set_model_fk(p_id integer, p_model_fk integer) OWNER TO postgres;

--
-- Name: meta_script_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_script
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_script_set_text(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_set_text(p_id integer, p_text text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_script
SET text = p_text
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_set_text(p_id integer, p_text text) OWNER TO postgres;

--
-- Name: meta_script_set_version(integer, numeric); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_set_version(p_id integer, p_version numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_script
SET version = p_version
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_set_version(p_id integer, p_version numeric) OWNER TO postgres;

--
-- Name: meta_script_upd(integer, integer, text, numeric, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_script_upd(p_id integer, p_model_fk integer, p_name text, p_version numeric, p_text text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_script_set_model_fk(p_id, p_model_fk);

PERFORM meta_script_set_name(p_id, p_name);

PERFORM meta_script_set_version(p_id, p_version);

PERFORM meta_script_set_text(p_id, p_text);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_script_upd(p_id integer, p_model_fk integer, p_name text, p_version numeric, p_text text) OWNER TO postgres;

--
-- Name: meta_variant_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_variant WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_del(p_id integer) OWNER TO postgres;

--
-- Name: meta_variant_ins(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_ins(p_model_fk integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_variant(
	model_fk,
	name)
VALUES(
	p_model_fk,
	p_name) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_ins(p_model_fk integer, p_name text) OWNER TO postgres;

--
-- Name: meta_variant_set_model_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_set_model_fk(p_id integer, p_model_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant
SET model_fk = p_model_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_set_model_fk(p_id integer, p_model_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: meta_variant_structure_del(bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_del(p_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM meta_variant_structure WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_del(p_id bigint) OWNER TO postgres;

--
-- Name: meta_variant_structure_ins(integer, integer, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_ins(p_variant_fk integer, p_item_fk integer, p_attribute_fk integer, p_equipment_fk integer, p_unit_fk integer, p_status integer, p_precision integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO meta_variant_structure(
	variant_fk,
	item_fk,
	attribute_fk,
	equipment_fk,
	unit_fk,
	status,
	precision)
VALUES(
	p_variant_fk,
	p_item_fk,
	p_attribute_fk,
	p_equipment_fk,
	p_unit_fk,
	p_status,
	p_precision) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_ins(p_variant_fk integer, p_item_fk integer, p_attribute_fk integer, p_equipment_fk integer, p_unit_fk integer, p_status integer, p_precision integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_attribute_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_attribute_fk(p_id bigint, p_attribute_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET attribute_fk = p_attribute_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_attribute_fk(p_id bigint, p_attribute_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_equipment_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_equipment_fk(p_id bigint, p_equipment_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET equipment_fk = p_equipment_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_equipment_fk(p_id bigint, p_equipment_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_item_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_item_fk(p_id bigint, p_item_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET item_fk = p_item_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_item_fk(p_id bigint, p_item_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_precision(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_precision(p_id bigint, p_precision integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET precision = p_precision
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_precision(p_id bigint, p_precision integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_status(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_status(p_id bigint, p_status integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET status = p_status
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_status(p_id bigint, p_status integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_unit_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_unit_fk(p_id bigint, p_unit_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET unit_fk = p_unit_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_unit_fk(p_id bigint, p_unit_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_set_variant_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_set_variant_fk(p_id bigint, p_variant_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE meta_variant_structure
SET variant_fk = p_variant_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_set_variant_fk(p_id bigint, p_variant_fk integer) OWNER TO postgres;

--
-- Name: meta_variant_structure_upd(bigint, integer, integer, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_structure_upd(p_id bigint, p_variant_fk integer, p_item_fk integer, p_attribute_fk integer, p_equipment_fk integer, p_unit_fk integer, p_status integer, p_precision integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_variant_structure_set_variant_fk(p_id, p_variant_fk);

PERFORM meta_variant_structure_set_item_fk(p_id, p_item_fk);

PERFORM meta_variant_structure_set_attribute_fk(p_id, p_attribute_fk);

PERFORM meta_variant_structure_set_equipment_fk(p_id, p_equipment_fk);

PERFORM meta_variant_structure_set_unit_fk(p_id, p_unit_fk);

PERFORM meta_variant_structure_set_status(p_id, p_status);

PERFORM meta_variant_structure_set_precision(p_id, p_precision);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_structure_upd(p_id bigint, p_variant_fk integer, p_item_fk integer, p_attribute_fk integer, p_equipment_fk integer, p_unit_fk integer, p_status integer, p_precision integer) OWNER TO postgres;

--
-- Name: meta_variant_upd(integer, integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.meta_variant_upd(p_id integer, p_model_fk integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM meta_variant_set_model_fk(p_id, p_model_fk);

PERFORM meta_variant_set_name(p_id, p_name);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.meta_variant_upd(p_id integer, p_model_fk integer, p_name text) OWNER TO postgres;

--
-- Name: obj_main_del(bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.obj_main_del(p_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM obj_main WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.obj_main_del(p_id bigint) OWNER TO postgres;

--
-- Name: obj_main_ins(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.obj_main_ins(p_entity_fk integer, p_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO obj_main(
	entity_fk,
	name)
VALUES(
	p_entity_fk,
	p_name) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.obj_main_ins(p_entity_fk integer, p_name text) OWNER TO postgres;

--
-- Name: obj_main_set_entity_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.obj_main_set_entity_fk(p_id bigint, p_entity_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE obj_main
SET entity_fk = p_entity_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.obj_main_set_entity_fk(p_id bigint, p_entity_fk integer) OWNER TO postgres;

--
-- Name: obj_main_set_name(bigint, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.obj_main_set_name(p_id bigint, p_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE obj_main
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.obj_main_set_name(p_id bigint, p_name text) OWNER TO postgres;

--
-- Name: obj_main_upd(bigint, integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.obj_main_upd(p_id bigint, p_entity_fk integer, p_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM obj_main_set_entity_fk(p_id, p_entity_fk);

PERFORM obj_main_set_name(p_id, p_name);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.obj_main_upd(p_id bigint, p_entity_fk integer, p_name text) OWNER TO postgres;

--
-- Name: prcs_plan_del(bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_del(p_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM prcs_plan WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_del(p_id bigint) OWNER TO postgres;

--
-- Name: prcs_plan_ins(bigint, integer, boolean, boolean); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_ins(p_object_fk bigint, p_stage_fk integer, p_value boolean, p_status boolean) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO prcs_plan(
	object_fk,
	stage_fk,
	value,
	status)
VALUES(
	p_object_fk,
	p_stage_fk,
	p_value,
	p_status) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_ins(p_object_fk bigint, p_stage_fk integer, p_value boolean, p_status boolean) OWNER TO postgres;

--
-- Name: prcs_plan_set_object_fk(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_set_object_fk(p_id bigint, p_object_fk bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_plan
SET object_fk = p_object_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_set_object_fk(p_id bigint, p_object_fk bigint) OWNER TO postgres;

--
-- Name: prcs_plan_set_stage_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_set_stage_fk(p_id bigint, p_stage_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_plan
SET stage_fk = p_stage_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_set_stage_fk(p_id bigint, p_stage_fk integer) OWNER TO postgres;

--
-- Name: prcs_plan_set_status(bigint, boolean); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_set_status(p_id bigint, p_status boolean) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_plan
SET status = p_status
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_set_status(p_id bigint, p_status boolean) OWNER TO postgres;

--
-- Name: prcs_plan_set_value(bigint, boolean); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_set_value(p_id bigint, p_value boolean) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_plan
SET value = p_value
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_set_value(p_id bigint, p_value boolean) OWNER TO postgres;

--
-- Name: prcs_plan_upd(bigint, bigint, integer, boolean, boolean); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_plan_upd(p_id bigint, p_object_fk bigint, p_stage_fk integer, p_value boolean, p_status boolean) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM prcs_plan_set_object_fk(p_id, p_object_fk);

PERFORM prcs_plan_set_stage_fk(p_id, p_stage_fk);

PERFORM prcs_plan_set_value(p_id, p_value);

PERFORM prcs_plan_set_status(p_id, p_status);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_plan_upd(p_id bigint, p_object_fk bigint, p_stage_fk integer, p_value boolean, p_status boolean) OWNER TO postgres;

--
-- Name: prcs_stage_del(integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_del(p_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM prcs_stage WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_del(p_id integer) OWNER TO postgres;

--
-- Name: prcs_stage_ins(text, text, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_ins(p_name text, p_abbreviation text, p_department_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO prcs_stage(
	name,
	abbreviation,
	department_fk)
VALUES(
	p_name,
	p_abbreviation,
	p_department_fk) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_ins(p_name text, p_abbreviation text, p_department_fk integer) OWNER TO postgres;

--
-- Name: prcs_stage_set_abbreviation(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_set_abbreviation(p_id integer, p_abbreviation text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_stage
SET abbreviation = p_abbreviation
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_set_abbreviation(p_id integer, p_abbreviation text) OWNER TO postgres;

--
-- Name: prcs_stage_set_department_fk(integer, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_set_department_fk(p_id integer, p_department_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_stage
SET department_fk = p_department_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_set_department_fk(p_id integer, p_department_fk integer) OWNER TO postgres;

--
-- Name: prcs_stage_set_name(integer, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_set_name(p_id integer, p_name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_stage
SET name = p_name
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_set_name(p_id integer, p_name text) OWNER TO postgres;

--
-- Name: prcs_stage_upd(integer, text, text, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_stage_upd(p_id integer, p_name text, p_abbreviation text, p_department_fk integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM prcs_stage_set_name(p_id, p_name);

PERFORM prcs_stage_set_abbreviation(p_id, p_abbreviation);

PERFORM prcs_stage_set_department_fk(p_id, p_department_fk);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_stage_upd(p_id integer, p_name text, p_abbreviation text, p_department_fk integer) OWNER TO postgres;

--
-- Name: prcs_task_del(bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_del(p_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM prcs_task WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_del(p_id bigint) OWNER TO postgres;

--
-- Name: prcs_task_ins(date, date, integer, integer, text, bigint, integer, bigint, bigint, date, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_ins(p_date_begin date, p_date_end date, p_status integer, p_script_fk integer, p_note text, p_plan_fk bigint, p_stage_fk integer, p_object_fk bigint, p_order_fk bigint, p_deadline date, p_priority integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO prcs_task(
	date_begin,
	date_end,
	status,
	script_fk,
	note,
	plan_fk,
	stage_fk,
	object_fk,
	order_fk,
	deadline,
	priority)
VALUES(
	p_date_begin,
	p_date_end,
	p_status,
	p_script_fk,
	p_note,
	p_plan_fk,
	p_stage_fk,
	p_object_fk,
	p_order_fk,
	p_deadline,
	p_priority) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_ins(p_date_begin date, p_date_end date, p_status integer, p_script_fk integer, p_note text, p_plan_fk bigint, p_stage_fk integer, p_object_fk bigint, p_order_fk bigint, p_deadline date, p_priority integer) OWNER TO postgres;

--
-- Name: prcs_task_set_date_begin(bigint, date); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_date_begin(p_id bigint, p_date_begin date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET date_begin = p_date_begin
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_date_begin(p_id bigint, p_date_begin date) OWNER TO postgres;

--
-- Name: prcs_task_set_date_end(bigint, date); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_date_end(p_id bigint, p_date_end date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET date_end = p_date_end
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_date_end(p_id bigint, p_date_end date) OWNER TO postgres;

--
-- Name: prcs_task_set_deadline(bigint, date); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_deadline(p_id bigint, p_deadline date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET deadline = p_deadline
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_deadline(p_id bigint, p_deadline date) OWNER TO postgres;

--
-- Name: prcs_task_set_note(bigint, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_note(p_id bigint, p_note text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET note = p_note
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_note(p_id bigint, p_note text) OWNER TO postgres;

--
-- Name: prcs_task_set_object_fk(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_object_fk(p_id bigint, p_object_fk bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET object_fk = p_object_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_object_fk(p_id bigint, p_object_fk bigint) OWNER TO postgres;

--
-- Name: prcs_task_set_order_fk(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_order_fk(p_id bigint, p_order_fk bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET order_fk = p_order_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_order_fk(p_id bigint, p_order_fk bigint) OWNER TO postgres;

--
-- Name: prcs_task_set_plan_fk(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_plan_fk(p_id bigint, p_plan_fk bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET plan_fk = p_plan_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_plan_fk(p_id bigint, p_plan_fk bigint) OWNER TO postgres;

--
-- Name: prcs_task_set_priority(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_priority(p_id bigint, p_priority integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET priority = p_priority
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_priority(p_id bigint, p_priority integer) OWNER TO postgres;

--
-- Name: prcs_task_set_script_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_script_fk(p_id bigint, p_script_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET script_fk = p_script_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_script_fk(p_id bigint, p_script_fk integer) OWNER TO postgres;

--
-- Name: prcs_task_set_stage_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_stage_fk(p_id bigint, p_stage_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET stage_fk = p_stage_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_stage_fk(p_id bigint, p_stage_fk integer) OWNER TO postgres;

--
-- Name: prcs_task_set_status(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_set_status(p_id bigint, p_status integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE prcs_task
SET status = p_status
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_set_status(p_id bigint, p_status integer) OWNER TO postgres;

--
-- Name: prcs_task_upd(bigint, date, date, integer, integer, text, bigint, integer, bigint, bigint, date, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.prcs_task_upd(p_id bigint, p_date_begin date, p_date_end date, p_status integer, p_script_fk integer, p_note text, p_plan_fk bigint, p_stage_fk integer, p_object_fk bigint, p_order_fk bigint, p_deadline date, p_priority integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM prcs_task_set_date_begin(p_id, p_date_begin);

PERFORM prcs_task_set_date_end(p_id, p_date_end);

PERFORM prcs_task_set_status(p_id, p_status);

PERFORM prcs_task_set_script_fk(p_id, p_script_fk);

PERFORM prcs_task_set_note(p_id, p_note);

PERFORM prcs_task_set_plan_fk(p_id, p_plan_fk);

PERFORM prcs_task_set_stage_fk(p_id, p_stage_fk);

PERFORM prcs_task_set_object_fk(p_id, p_object_fk);

PERFORM prcs_task_set_order_fk(p_id, p_order_fk);

PERFORM prcs_task_set_deadline(p_id, p_deadline);

PERFORM prcs_task_set_priority(p_id, p_priority);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.prcs_task_upd(p_id bigint, p_date_begin date, p_date_end date, p_status integer, p_script_fk integer, p_note text, p_plan_fk bigint, p_stage_fk integer, p_object_fk bigint, p_order_fk bigint, p_deadline date, p_priority integer) OWNER TO postgres;

--
-- Name: result_main_del(bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_del(p_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

DELETE FROM result_main WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the delete';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_del(p_id bigint) OWNER TO postgres;

--
-- Name: result_main_ins(integer, integer, integer, bigint, integer, integer, bigint, numeric, integer, date, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_ins(p_unit_fk integer, p_apparatus_fk integer, p_status integer, p_task_fk bigint, p_item_fk integer, p_attribute_fk integer, p_row_id bigint, p_value_num numeric, p_value_dict integer, p_value_date date, p_value_str text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_id integer := -1;
	v_count integer := 0;
BEGIN

INSERT INTO result_main(
	unit_fk,
	apparatus_fk,
	status,
	task_fk,
	item_fk,
	attribute_fk,
	row_id,
	value_num,
	value_dict,
	value_date,
	value_str)
VALUES(
	p_unit_fk,
	p_apparatus_fk,
	p_status,
	p_task_fk,
	p_item_fk,
	p_attribute_fk,
	p_row_id,
	p_value_num,
	p_value_dict,
	p_value_date,
	p_value_str) RETURNING id INTO v_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the insert';
END IF;

RETURN v_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_ins(p_unit_fk integer, p_apparatus_fk integer, p_status integer, p_task_fk bigint, p_item_fk integer, p_attribute_fk integer, p_row_id bigint, p_value_num numeric, p_value_dict integer, p_value_date date, p_value_str text) OWNER TO postgres;

--
-- Name: result_main_set_apparatus_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_apparatus_fk(p_id bigint, p_apparatus_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET apparatus_fk = p_apparatus_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_apparatus_fk(p_id bigint, p_apparatus_fk integer) OWNER TO postgres;

--
-- Name: result_main_set_attribute_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_attribute_fk(p_id bigint, p_attribute_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET attribute_fk = p_attribute_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_attribute_fk(p_id bigint, p_attribute_fk integer) OWNER TO postgres;

--
-- Name: result_main_set_item_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_item_fk(p_id bigint, p_item_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET item_fk = p_item_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_item_fk(p_id bigint, p_item_fk integer) OWNER TO postgres;

--
-- Name: result_main_set_row_id(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_row_id(p_id bigint, p_row_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET row_id = p_row_id
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_row_id(p_id bigint, p_row_id bigint) OWNER TO postgres;

--
-- Name: result_main_set_status(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_status(p_id bigint, p_status integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET status = p_status
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_status(p_id bigint, p_status integer) OWNER TO postgres;

--
-- Name: result_main_set_task_fk(bigint, bigint); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_task_fk(p_id bigint, p_task_fk bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET task_fk = p_task_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_task_fk(p_id bigint, p_task_fk bigint) OWNER TO postgres;

--
-- Name: result_main_set_unit_fk(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_unit_fk(p_id bigint, p_unit_fk integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET unit_fk = p_unit_fk
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_unit_fk(p_id bigint, p_unit_fk integer) OWNER TO postgres;

--
-- Name: result_main_set_value_date(bigint, date); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_value_date(p_id bigint, p_value_date date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET value_date = p_value_date
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_value_date(p_id bigint, p_value_date date) OWNER TO postgres;

--
-- Name: result_main_set_value_dict(bigint, integer); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_value_dict(p_id bigint, p_value_dict integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET value_dict = p_value_dict
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_value_dict(p_id bigint, p_value_dict integer) OWNER TO postgres;

--
-- Name: result_main_set_value_num(bigint, numeric); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_value_num(p_id bigint, p_value_num numeric) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET value_num = p_value_num
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_value_num(p_id bigint, p_value_num numeric) OWNER TO postgres;

--
-- Name: result_main_set_value_str(bigint, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_set_value_str(p_id bigint, p_value_str text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_count integer := 0;
BEGIN

UPDATE result_main
SET value_str = p_value_str
WHERE id = p_id;
GET DIAGNOSTICS v_count = ROW_COUNT;
IF v_count = 0 THEN
	RAISE EXCEPTION 'No rows were affected in the update';
END IF;

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_set_value_str(p_id bigint, p_value_str text) OWNER TO postgres;

--
-- Name: result_main_upd(bigint, integer, integer, integer, bigint, integer, integer, bigint, numeric, integer, date, text); Type: FUNCTION; Schema: lims; Owner: postgres
--

CREATE FUNCTION lims.result_main_upd(p_id bigint, p_unit_fk integer, p_apparatus_fk integer, p_status integer, p_task_fk bigint, p_item_fk integer, p_attribute_fk integer, p_row_id bigint, p_value_num numeric, p_value_dict integer, p_value_date date, p_value_str text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN

PERFORM result_main_set_unit_fk(p_id, p_unit_fk);

PERFORM result_main_set_apparatus_fk(p_id, p_apparatus_fk);

PERFORM result_main_set_status(p_id, p_status);

PERFORM result_main_set_task_fk(p_id, p_task_fk);

PERFORM result_main_set_item_fk(p_id, p_item_fk);

PERFORM result_main_set_attribute_fk(p_id, p_attribute_fk);

PERFORM result_main_set_row_id(p_id, p_row_id);

PERFORM result_main_set_value_num(p_id, p_value_num);

PERFORM result_main_set_value_dict(p_id, p_value_dict);

PERFORM result_main_set_value_date(p_id, p_value_date);

PERFORM result_main_set_value_str(p_id, p_value_str);

RETURN p_id;

EXCEPTION
WHEN OTHERS THEN
	RAISE EXCEPTION 'Exception %: %', SQLSTATE, SQLERRM;
END;
$$;


ALTER FUNCTION lims.result_main_upd(p_id bigint, p_unit_fk integer, p_apparatus_fk integer, p_status integer, p_task_fk bigint, p_item_fk integer, p_attribute_fk integer, p_row_id bigint, p_value_num numeric, p_value_dict integer, p_value_date date, p_value_str text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crm_client; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_client (
    id integer NOT NULL,
    city_fk integer,
    address text,
    phone integer,
    email text,
    status boolean DEFAULT true NOT NULL,
    type text NOT NULL,
    CONSTRAINT client_type_ck CHECK ((type = ANY (ARRAY['COMPANY'::text, 'PERSON'::text])))
);


ALTER TABLE lims.crm_client OWNER TO postgres;

--
-- Name: TABLE crm_client; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_client IS 'Клиенты (супертип)';


--
-- Name: COLUMN crm_client.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.id IS 'Идентификатор';


--
-- Name: COLUMN crm_client.city_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.city_fk IS 'Ключ города';


--
-- Name: COLUMN crm_client.address; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.address IS 'Адрес';


--
-- Name: COLUMN crm_client.phone; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.phone IS 'Телефон';


--
-- Name: COLUMN crm_client.email; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.email IS 'Электронная почта';


--
-- Name: COLUMN crm_client.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.status IS 'Статус';


--
-- Name: COLUMN crm_client.type; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_client.type IS 'Тип';


--
-- Name: crm_client_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.crm_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.crm_client_id_seq OWNER TO postgres;

--
-- Name: crm_client_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.crm_client_id_seq OWNED BY lims.crm_client.id;


--
-- Name: crm_company; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_company (
    id_fk integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE lims.crm_company OWNER TO postgres;

--
-- Name: TABLE crm_company; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_company IS 'Клиенты (юридические лица)';


--
-- Name: COLUMN crm_company.id_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_company.id_fk IS 'Идентификатор супертипа';


--
-- Name: COLUMN crm_company.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_company.name IS 'Название';


--
-- Name: crm_material_price; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_material_price (
    id bigint NOT NULL,
    material_fk bigint NOT NULL,
    price numeric NOT NULL,
    currency_fk integer NOT NULL,
    volume numeric DEFAULT 1 NOT NULL,
    unit_fk integer NOT NULL,
    CONSTRAINT material_price_price_ck CHECK ((price > (0)::numeric)),
    CONSTRAINT material_price_volume_ck CHECK ((volume > (0)::numeric))
);


ALTER TABLE lims.crm_material_price OWNER TO postgres;

--
-- Name: TABLE crm_material_price; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_material_price IS 'Прайс материалов';


--
-- Name: COLUMN crm_material_price.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.id IS 'Идентификатор';


--
-- Name: COLUMN crm_material_price.material_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.material_fk IS 'Ключ материала';


--
-- Name: COLUMN crm_material_price.price; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.price IS 'Цена';


--
-- Name: COLUMN crm_material_price.currency_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.currency_fk IS 'Ключ валюты';


--
-- Name: COLUMN crm_material_price.volume; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.volume IS 'Объем';


--
-- Name: COLUMN crm_material_price.unit_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_material_price.unit_fk IS 'Ключ единицы измерения';


--
-- Name: crm_material_price_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.crm_material_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.crm_material_price_id_seq OWNER TO postgres;

--
-- Name: crm_material_price_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.crm_material_price_id_seq OWNED BY lims.crm_material_price.id;


--
-- Name: crm_order; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_order (
    id bigint NOT NULL,
    client_fk integer,
    name text NOT NULL,
    manager_fk integer,
    date_contract date DEFAULT (now())::date,
    note text,
    status integer DEFAULT 0 NOT NULL,
    CONSTRAINT order_status_ck CHECK ((status = ANY (ARRAY[0, 1, 2])))
);


ALTER TABLE lims.crm_order OWNER TO postgres;

--
-- Name: TABLE crm_order; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_order IS 'Заказы';


--
-- Name: COLUMN crm_order.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.id IS 'Идентификатор';


--
-- Name: COLUMN crm_order.client_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.client_fk IS 'Ключ клиента';


--
-- Name: COLUMN crm_order.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.name IS 'Номер договора';


--
-- Name: COLUMN crm_order.manager_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.manager_fk IS 'Ключ работника';


--
-- Name: COLUMN crm_order.date_contract; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.date_contract IS 'Дата договора';


--
-- Name: COLUMN crm_order.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.note IS 'Примечание';


--
-- Name: COLUMN crm_order.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_order.status IS 'Статус';


--
-- Name: crm_order_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.crm_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.crm_order_id_seq OWNER TO postgres;

--
-- Name: crm_order_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.crm_order_id_seq OWNED BY lims.crm_order.id;


--
-- Name: crm_person; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_person (
    id_fk integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    middle_name text
);


ALTER TABLE lims.crm_person OWNER TO postgres;

--
-- Name: TABLE crm_person; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_person IS 'Клиенты (физические лица)';


--
-- Name: COLUMN crm_person.id_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_person.id_fk IS 'Идентификатор супертипа';


--
-- Name: COLUMN crm_person.first_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_person.first_name IS 'Имя';


--
-- Name: COLUMN crm_person.last_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_person.last_name IS 'Фамилия';


--
-- Name: COLUMN crm_person.middle_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_person.middle_name IS 'Отчество';


--
-- Name: crm_work_price; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.crm_work_price (
    id bigint NOT NULL,
    work_fk integer NOT NULL,
    price numeric NOT NULL,
    currency_fk integer NOT NULL,
    volume numeric DEFAULT 1 NOT NULL,
    CONSTRAINT work_price_price_ck CHECK ((price > (0)::numeric)),
    CONSTRAINT work_price_volume_ck CHECK ((volume > (0)::numeric))
);


ALTER TABLE lims.crm_work_price OWNER TO postgres;

--
-- Name: TABLE crm_work_price; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.crm_work_price IS 'Прайс работ';


--
-- Name: COLUMN crm_work_price.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_work_price.id IS 'Идентификатор';


--
-- Name: COLUMN crm_work_price.work_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_work_price.work_fk IS 'Ключ работы';


--
-- Name: COLUMN crm_work_price.price; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_work_price.price IS 'Цена';


--
-- Name: COLUMN crm_work_price.currency_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_work_price.currency_fk IS 'Ключ валюты';


--
-- Name: COLUMN crm_work_price.volume; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.crm_work_price.volume IS 'Объем';


--
-- Name: crm_work_price_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.crm_work_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.crm_work_price_id_seq OWNER TO postgres;

--
-- Name: crm_work_price_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.crm_work_price_id_seq OWNED BY lims.crm_work_price.id;


--
-- Name: dict_city; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_city (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE lims.dict_city OWNER TO postgres;

--
-- Name: TABLE dict_city; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_city IS 'Справочник городов';


--
-- Name: COLUMN dict_city.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_city.id IS 'Идентиикатор';


--
-- Name: COLUMN dict_city.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_city.name IS 'Название';


--
-- Name: dict_city_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_city_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_city_id_seq OWNER TO postgres;

--
-- Name: dict_city_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_city_id_seq OWNED BY lims.dict_city.id;


--
-- Name: dict_currency; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_currency (
    id integer NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL
);


ALTER TABLE lims.dict_currency OWNER TO postgres;

--
-- Name: TABLE dict_currency; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_currency IS 'Справочник валют';


--
-- Name: COLUMN dict_currency.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_currency.id IS 'Идентиикатор';


--
-- Name: COLUMN dict_currency.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_currency.name IS 'Название';


--
-- Name: COLUMN dict_currency.symbol; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_currency.symbol IS 'Символ';


--
-- Name: dict_currency_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_currency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_currency_id_seq OWNER TO postgres;

--
-- Name: dict_currency_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_currency_id_seq OWNED BY lims.dict_currency.id;


--
-- Name: dict_decision; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_decision (
    id integer NOT NULL,
    name text NOT NULL,
    note text,
    parent_fk integer,
    CONSTRAINT dict_decision_parent_ck CHECK ((parent_fk <> id))
);


ALTER TABLE lims.dict_decision OWNER TO postgres;

--
-- Name: TABLE dict_decision; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_decision IS 'Справочник решений (группа работ)';


--
-- Name: COLUMN dict_decision.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_decision.id IS 'Идентиикатор';


--
-- Name: COLUMN dict_decision.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_decision.name IS 'Название';


--
-- Name: COLUMN dict_decision.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_decision.note IS 'Описание';


--
-- Name: COLUMN dict_decision.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_decision.parent_fk IS 'Ключ родителя';


--
-- Name: dict_decision_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_decision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_decision_id_seq OWNER TO postgres;

--
-- Name: dict_decision_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_decision_id_seq OWNED BY lims.dict_decision.id;


--
-- Name: dict_inventory; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_inventory (
    id integer NOT NULL,
    name text NOT NULL,
    note text,
    parent_fk integer,
    CONSTRAINT inventory_parent_ck CHECK ((parent_fk <> id))
);


ALTER TABLE lims.dict_inventory OWNER TO postgres;

--
-- Name: TABLE dict_inventory; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_inventory IS 'Справочник инвентаря (группа материалов)';


--
-- Name: COLUMN dict_inventory.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_inventory.id IS 'Идентификатор';


--
-- Name: COLUMN dict_inventory.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_inventory.name IS 'Название';


--
-- Name: COLUMN dict_inventory.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_inventory.note IS 'Описание';


--
-- Name: COLUMN dict_inventory.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_inventory.parent_fk IS 'Ключ родителя';


--
-- Name: dict_inventory_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_inventory_id_seq OWNER TO postgres;

--
-- Name: dict_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_inventory_id_seq OWNED BY lims.dict_inventory.id;


--
-- Name: dict_main; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_main (
    id integer NOT NULL,
    name text NOT NULL,
    note text,
    parent_fk integer,
    order_num integer NOT NULL,
    CONSTRAINT dictionary_order_num_ck CHECK ((order_num >= 0)),
    CONSTRAINT dictionary_parent_ck CHECK ((parent_fk <> id))
);


ALTER TABLE lims.dict_main OWNER TO postgres;

--
-- Name: TABLE dict_main; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_main IS 'Справочник (основной)';


--
-- Name: COLUMN dict_main.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_main.id IS 'Идентификатор';


--
-- Name: COLUMN dict_main.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_main.name IS 'Название';


--
-- Name: COLUMN dict_main.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_main.note IS 'Описание';


--
-- Name: COLUMN dict_main.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_main.parent_fk IS 'Ключ родителя';


--
-- Name: COLUMN dict_main.order_num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_main.order_num IS 'Порядок сортировки';


--
-- Name: dict_main_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_main_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_main_id_seq OWNER TO postgres;

--
-- Name: dict_main_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_main_id_seq OWNED BY lims.dict_main.id;


--
-- Name: dict_sequence; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_sequence (
    id integer NOT NULL,
    name text NOT NULL,
    department_fk integer NOT NULL
);


ALTER TABLE lims.dict_sequence OWNER TO postgres;

--
-- Name: TABLE dict_sequence; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_sequence IS 'Справочник последовательностей (группа этапов)';


--
-- Name: COLUMN dict_sequence.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_sequence.id IS 'Идентификатор';


--
-- Name: COLUMN dict_sequence.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_sequence.name IS 'Название';


--
-- Name: COLUMN dict_sequence.department_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_sequence.department_fk IS 'Ключ подразделения';


--
-- Name: dict_sequence_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_sequence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_sequence_id_seq OWNER TO postgres;

--
-- Name: dict_sequence_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_sequence_id_seq OWNED BY lims.dict_sequence.id;


--
-- Name: dict_unit; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.dict_unit (
    id integer NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL
);


ALTER TABLE lims.dict_unit OWNER TO postgres;

--
-- Name: TABLE dict_unit; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.dict_unit IS 'Справочник единиц измерения';


--
-- Name: COLUMN dict_unit.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_unit.id IS 'Идентификатор';


--
-- Name: COLUMN dict_unit.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_unit.name IS 'Название';


--
-- Name: COLUMN dict_unit.symbol; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.dict_unit.symbol IS 'Описание';


--
-- Name: dict_unit_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.dict_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.dict_unit_id_seq OWNER TO postgres;

--
-- Name: dict_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.dict_unit_id_seq OWNED BY lims.dict_unit.id;


--
-- Name: eqp_apparatus; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.eqp_apparatus (
    id integer NOT NULL,
    equipment_fk integer NOT NULL,
    department_fk integer NOT NULL,
    num text NOT NULL,
    name text NOT NULL,
    status boolean DEFAULT true NOT NULL
);


ALTER TABLE lims.eqp_apparatus OWNER TO postgres;

--
-- Name: TABLE eqp_apparatus; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.eqp_apparatus IS 'Приборы (физическое)';


--
-- Name: COLUMN eqp_apparatus.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.id IS 'Идентификатор';


--
-- Name: COLUMN eqp_apparatus.equipment_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.equipment_fk IS 'Ключ модели';


--
-- Name: COLUMN eqp_apparatus.department_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.department_fk IS 'Ключ подразделения';


--
-- Name: COLUMN eqp_apparatus.num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.num IS 'Номер';


--
-- Name: COLUMN eqp_apparatus.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.name IS 'Название';


--
-- Name: COLUMN eqp_apparatus.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_apparatus.status IS 'Статус';


--
-- Name: eqp_apparatus_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.eqp_apparatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.eqp_apparatus_id_seq OWNER TO postgres;

--
-- Name: eqp_apparatus_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.eqp_apparatus_id_seq OWNED BY lims.eqp_apparatus.id;


--
-- Name: eqp_equipment; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.eqp_equipment (
    id integer NOT NULL,
    group_fk integer NOT NULL,
    name text NOT NULL,
    note text
);


ALTER TABLE lims.eqp_equipment OWNER TO postgres;

--
-- Name: TABLE eqp_equipment; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.eqp_equipment IS 'Приборы (логические)';


--
-- Name: COLUMN eqp_equipment.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_equipment.id IS 'Идентификатор';


--
-- Name: COLUMN eqp_equipment.group_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_equipment.group_fk IS 'Ключ группы приборов';


--
-- Name: COLUMN eqp_equipment.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_equipment.name IS 'Название';


--
-- Name: COLUMN eqp_equipment.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.eqp_equipment.note IS 'Примечание';


--
-- Name: eqp_equipment_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.eqp_equipment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.eqp_equipment_id_seq OWNER TO postgres;

--
-- Name: eqp_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.eqp_equipment_id_seq OWNED BY lims.eqp_equipment.id;


--
-- Name: tag_task; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tag_task (
    id bigint NOT NULL,
    tag_fk integer NOT NULL,
    task_fk bigint NOT NULL
);


ALTER TABLE lims.tag_task OWNER TO postgres;

--
-- Name: TABLE tag_task; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tag_task IS 'Таги заданий';


--
-- Name: COLUMN tag_task.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_task.id IS 'Идентификатор';


--
-- Name: COLUMN tag_task.tag_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_task.tag_fk IS 'Ключ тага';


--
-- Name: COLUMN tag_task.task_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_task.task_fk IS 'Ключ задания';


--
-- Name: tag_client_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tag_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tag_client_id_seq OWNER TO postgres;

--
-- Name: tag_client_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tag_client_id_seq OWNED BY lims.tag_task.id;


--
-- Name: file_client; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.file_client (
    id bigint DEFAULT nextval('lims.tag_client_id_seq'::regclass) NOT NULL,
    file_fk bigint NOT NULL,
    client_fk integer NOT NULL
);


ALTER TABLE lims.file_client OWNER TO postgres;

--
-- Name: TABLE file_client; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.file_client IS 'Файлы клиентов';


--
-- Name: COLUMN file_client.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_client.id IS 'Идентификатор';


--
-- Name: COLUMN file_client.file_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_client.file_fk IS 'Ключ файла';


--
-- Name: COLUMN file_client.client_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_client.client_fk IS 'Ключ клиента';


--
-- Name: file_client_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.file_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.file_client_id_seq OWNER TO postgres;

--
-- Name: file_client_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.file_client_id_seq OWNED BY lims.file_client.id;


--
-- Name: file_main; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.file_main (
    id bigint NOT NULL,
    name text NOT NULL,
    extension character varying(4) NOT NULL,
    group_fk integer NOT NULL,
    thumbnail bytea NOT NULL,
    file_size bigint NOT NULL,
    md5 uuid NOT NULL,
    file_path text NOT NULL,
    status boolean DEFAULT true NOT NULL,
    CONSTRAINT reference_file_size_ck CHECK ((file_size > 0))
);


ALTER TABLE lims.file_main OWNER TO postgres;

--
-- Name: TABLE file_main; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.file_main IS 'Ссылки на файлы системы';


--
-- Name: COLUMN file_main.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.id IS 'Идентификатор';


--
-- Name: COLUMN file_main.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.name IS 'Название';


--
-- Name: COLUMN file_main.extension; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.extension IS 'Расширение';


--
-- Name: COLUMN file_main.group_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.group_fk IS 'Ключ группы';


--
-- Name: COLUMN file_main.thumbnail; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.thumbnail IS 'Миниатюра';


--
-- Name: COLUMN file_main.file_size; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.file_size IS 'Размер (байт)';


--
-- Name: COLUMN file_main.md5; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.md5 IS 'MD5 хэш';


--
-- Name: COLUMN file_main.file_path; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.file_path IS 'Путь к файлу';


--
-- Name: COLUMN file_main.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_main.status IS 'Статус';


--
-- Name: file_main_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.file_main_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.file_main_id_seq OWNER TO postgres;

--
-- Name: file_main_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.file_main_id_seq OWNED BY lims.file_main.id;


--
-- Name: tag_object; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tag_object (
    id bigint NOT NULL,
    tag_fk integer NOT NULL,
    object_fk bigint NOT NULL
);


ALTER TABLE lims.tag_object OWNER TO postgres;

--
-- Name: TABLE tag_object; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tag_object IS 'Таги объектов';


--
-- Name: COLUMN tag_object.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_object.id IS 'Идентификатор';


--
-- Name: COLUMN tag_object.tag_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_object.tag_fk IS 'Ключ тага';


--
-- Name: COLUMN tag_object.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_object.object_fk IS 'Ключ объекта';


--
-- Name: tag_object_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tag_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.tag_object_id_seq OWNER TO postgres;

--
-- Name: tag_object_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tag_object_id_seq OWNED BY lims.tag_object.id;


--
-- Name: file_object; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.file_object (
    id bigint DEFAULT nextval('lims.tag_object_id_seq'::regclass) NOT NULL,
    file_fk bigint NOT NULL,
    object_fk bigint NOT NULL
);


ALTER TABLE lims.file_object OWNER TO postgres;

--
-- Name: TABLE file_object; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.file_object IS 'Файлы объектов';


--
-- Name: COLUMN file_object.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_object.id IS 'Идентификатор';


--
-- Name: COLUMN file_object.file_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_object.file_fk IS 'Ключ файла';


--
-- Name: COLUMN file_object.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_object.object_fk IS 'Ключ объекта';


--
-- Name: file_object_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.file_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.file_object_id_seq OWNER TO postgres;

--
-- Name: file_object_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.file_object_id_seq OWNED BY lims.file_object.id;


--
-- Name: tag_order; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tag_order (
    id bigint NOT NULL,
    tag_fk integer NOT NULL,
    order_fk bigint NOT NULL
);


ALTER TABLE lims.tag_order OWNER TO postgres;

--
-- Name: TABLE tag_order; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tag_order IS 'Таги заказов';


--
-- Name: COLUMN tag_order.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_order.id IS 'Идентификатор';


--
-- Name: COLUMN tag_order.tag_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_order.tag_fk IS 'Ключ тага';


--
-- Name: COLUMN tag_order.order_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_order.order_fk IS 'Ключ заказа';


--
-- Name: tag_order_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tag_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tag_order_id_seq OWNER TO postgres;

--
-- Name: tag_order_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tag_order_id_seq OWNED BY lims.tag_order.id;


--
-- Name: file_order; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.file_order (
    id bigint DEFAULT nextval('lims.tag_order_id_seq'::regclass) NOT NULL,
    file_fk bigint NOT NULL,
    order_fk bigint NOT NULL
);


ALTER TABLE lims.file_order OWNER TO postgres;

--
-- Name: TABLE file_order; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.file_order IS 'Файлы заказов';


--
-- Name: COLUMN file_order.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_order.id IS 'Идентификатор';


--
-- Name: COLUMN file_order.file_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_order.file_fk IS 'Ключ файла';


--
-- Name: COLUMN file_order.order_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_order.order_fk IS 'Ключ заказа';


--
-- Name: file_order_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.file_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.file_order_id_seq OWNER TO postgres;

--
-- Name: file_order_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.file_order_id_seq OWNED BY lims.file_order.id;


--
-- Name: tag_client; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tag_client (
    id integer DEFAULT nextval('lims.tag_client_id_seq'::regclass) NOT NULL,
    tag_fk integer NOT NULL,
    client_fk integer NOT NULL
);


ALTER TABLE lims.tag_client OWNER TO postgres;

--
-- Name: TABLE tag_client; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tag_client IS 'Таги клиентов';


--
-- Name: COLUMN tag_client.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_client.id IS 'Идентификатор';


--
-- Name: COLUMN tag_client.tag_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_client.tag_fk IS 'Ключ тага';


--
-- Name: COLUMN tag_client.client_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_client.client_fk IS 'Ключ клиента';


--
-- Name: tag_task_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tag_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.tag_task_id_seq OWNER TO postgres;

--
-- Name: tag_task_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tag_task_id_seq OWNED BY lims.tag_client.id;


--
-- Name: file_task; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.file_task (
    id bigint DEFAULT nextval('lims.tag_task_id_seq'::regclass) NOT NULL,
    file_fk bigint NOT NULL,
    task_fk bigint NOT NULL
);


ALTER TABLE lims.file_task OWNER TO postgres;

--
-- Name: TABLE file_task; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.file_task IS 'Файлы заданий';


--
-- Name: COLUMN file_task.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_task.id IS 'Идентификатор';


--
-- Name: COLUMN file_task.file_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_task.file_fk IS 'Ключ файла';


--
-- Name: COLUMN file_task.task_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.file_task.task_fk IS 'Ключ задания';


--
-- Name: file_task_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.file_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.file_task_id_seq OWNER TO postgres;

--
-- Name: file_task_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.file_task_id_seq OWNED BY lims.file_task.id;


--
-- Name: grant_worker_privilege; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.grant_worker_privilege (
    id bigint NOT NULL,
    worker_fk integer NOT NULL,
    module_privilege_fk integer NOT NULL
);


ALTER TABLE lims.grant_worker_privilege OWNER TO postgres;

--
-- Name: TABLE grant_worker_privilege; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.grant_worker_privilege IS 'Разрешения для привилегий по работникам';


--
-- Name: COLUMN grant_worker_privilege.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_privilege.id IS 'Идентификатор';


--
-- Name: COLUMN grant_worker_privilege.worker_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_privilege.worker_fk IS 'Ключ работника';


--
-- Name: COLUMN grant_worker_privilege.module_privilege_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_privilege.module_privilege_fk IS 'Ключ модуля привилегии';


--
-- Name: grant_worker_privilege_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.grant_worker_privilege_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.grant_worker_privilege_id_seq OWNER TO postgres;

--
-- Name: grant_worker_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.grant_worker_privilege_id_seq OWNED BY lims.grant_worker_privilege.id;


--
-- Name: grant_worker_report; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.grant_worker_report (
    id bigint NOT NULL,
    worker_fk integer NOT NULL,
    report_fk integer NOT NULL
);


ALTER TABLE lims.grant_worker_report OWNER TO postgres;

--
-- Name: TABLE grant_worker_report; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.grant_worker_report IS 'Разрешения для отчетов по работникам';


--
-- Name: COLUMN grant_worker_report.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_report.id IS 'Идентификатор';


--
-- Name: COLUMN grant_worker_report.worker_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_report.worker_fk IS 'Ключ работника';


--
-- Name: COLUMN grant_worker_report.report_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_report.report_fk IS 'Ключ отчета';


--
-- Name: grant_worker_report_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.grant_worker_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.grant_worker_report_id_seq OWNER TO postgres;

--
-- Name: grant_worker_report_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.grant_worker_report_id_seq OWNED BY lims.grant_worker_report.id;


--
-- Name: grant_worker_stage; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.grant_worker_stage (
    id bigint NOT NULL,
    worker_fk integer NOT NULL,
    stage_fk integer NOT NULL,
    access_view boolean DEFAULT false NOT NULL,
    access_execute boolean DEFAULT false NOT NULL,
    access_manage boolean DEFAULT false NOT NULL
);


ALTER TABLE lims.grant_worker_stage OWNER TO postgres;

--
-- Name: TABLE grant_worker_stage; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.grant_worker_stage IS 'Разрешения для этапов по работникам';


--
-- Name: COLUMN grant_worker_stage.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.id IS 'Идентификатор';


--
-- Name: COLUMN grant_worker_stage.worker_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.worker_fk IS 'Ключ работника';


--
-- Name: COLUMN grant_worker_stage.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN grant_worker_stage.access_view; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.access_view IS 'Доступ на просмотр';


--
-- Name: COLUMN grant_worker_stage.access_execute; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.access_execute IS 'Доступ на выполнение';


--
-- Name: COLUMN grant_worker_stage.access_manage; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.grant_worker_stage.access_manage IS 'Доступ на управление';


--
-- Name: grant_worker_stage_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.grant_worker_stage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.grant_worker_stage_id_seq OWNER TO postgres;

--
-- Name: grant_worker_stage_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.grant_worker_stage_id_seq OWNED BY lims.grant_worker_stage.id;


--
-- Name: meta_attribute; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_attribute (
    id integer NOT NULL,
    name text NOT NULL,
    caption text,
    type text NOT NULL,
    CONSTRAINT attribute_type_ck CHECK ((type = ANY (ARRAY['NUM'::text, 'DICT'::text, 'DATE'::text, 'STR'::text])))
);


ALTER TABLE lims.meta_attribute OWNER TO postgres;

--
-- Name: TABLE meta_attribute; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_attribute IS 'Метаданные атрибутов';


--
-- Name: COLUMN meta_attribute.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_attribute.id IS 'Идентификатор';


--
-- Name: COLUMN meta_attribute.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_attribute.name IS 'Название';


--
-- Name: COLUMN meta_attribute.caption; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_attribute.caption IS 'Отображаемая подпись';


--
-- Name: COLUMN meta_attribute.type; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_attribute.type IS 'Тип';


--
-- Name: meta_attribute_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_attribute_id_seq OWNER TO postgres;

--
-- Name: meta_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_attribute_id_seq OWNED BY lims.meta_attribute.id;


--
-- Name: meta_item; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_item (
    id integer NOT NULL,
    name text NOT NULL,
    order_attribute_fk integer,
    caption text,
    type text NOT NULL,
    CONSTRAINT item_type_ck CHECK ((type = ANY (ARRAY['Single'::text, 'TableDynamic'::text])))
);


ALTER TABLE lims.meta_item OWNER TO postgres;

--
-- Name: TABLE meta_item; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_item IS 'Метаданные таблиц';


--
-- Name: COLUMN meta_item.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item.id IS 'Идентификатор';


--
-- Name: COLUMN meta_item.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item.name IS 'Название';


--
-- Name: COLUMN meta_item.order_attribute_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item.order_attribute_fk IS 'Ключ атрибута сортировки';


--
-- Name: COLUMN meta_item.caption; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item.caption IS 'Отображаемая подпись';


--
-- Name: COLUMN meta_item.type; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item.type IS 'Тип';


--
-- Name: meta_item_attribute; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_item_attribute (
    id integer NOT NULL,
    item_fk integer NOT NULL,
    attribute_fk integer NOT NULL,
    order_num integer NOT NULL,
    CONSTRAINT item_attribute_order_num_ck CHECK ((order_num >= 0))
);


ALTER TABLE lims.meta_item_attribute OWNER TO postgres;

--
-- Name: TABLE meta_item_attribute; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_item_attribute IS 'Метаданные атрибутов таблиц';


--
-- Name: COLUMN meta_item_attribute.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item_attribute.id IS 'Идентификатор';


--
-- Name: COLUMN meta_item_attribute.item_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item_attribute.item_fk IS 'Ключ таблицы';


--
-- Name: COLUMN meta_item_attribute.attribute_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item_attribute.attribute_fk IS 'Ключ атрибута';


--
-- Name: COLUMN meta_item_attribute.order_num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_item_attribute.order_num IS 'Порядковый номер';


--
-- Name: meta_item_attribute_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_item_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_item_attribute_id_seq OWNER TO postgres;

--
-- Name: meta_item_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_item_attribute_id_seq OWNED BY lims.meta_item_attribute.id;


--
-- Name: meta_item_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_item_id_seq OWNER TO postgres;

--
-- Name: meta_item_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_item_id_seq OWNED BY lims.meta_item.id;


--
-- Name: meta_model; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_model (
    id integer NOT NULL,
    name text NOT NULL,
    note text
);


ALTER TABLE lims.meta_model OWNER TO postgres;

--
-- Name: TABLE meta_model; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_model IS 'Метаданные моделей';


--
-- Name: COLUMN meta_model.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model.id IS 'Идентификатор';


--
-- Name: COLUMN meta_model.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model.name IS 'Название';


--
-- Name: COLUMN meta_model.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model.note IS 'Описание';


--
-- Name: meta_model_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_model_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_model_id_seq OWNER TO postgres;

--
-- Name: meta_model_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_model_id_seq OWNED BY lims.meta_model.id;


--
-- Name: meta_model_item; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_model_item (
    id integer NOT NULL,
    model_fk integer NOT NULL,
    item_fk integer NOT NULL
);


ALTER TABLE lims.meta_model_item OWNER TO postgres;

--
-- Name: TABLE meta_model_item; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_model_item IS 'Метаданные таблиц моделей';


--
-- Name: COLUMN meta_model_item.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model_item.id IS 'Идентификатор';


--
-- Name: COLUMN meta_model_item.model_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model_item.model_fk IS 'Ключ модели';


--
-- Name: COLUMN meta_model_item.item_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_model_item.item_fk IS 'Ключ таблицы';


--
-- Name: meta_model_item_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_model_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_model_item_id_seq OWNER TO postgres;

--
-- Name: meta_model_item_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_model_item_id_seq OWNED BY lims.meta_model_item.id;


--
-- Name: meta_module; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_module (
    id integer NOT NULL,
    name text NOT NULL,
    caption text NOT NULL
);


ALTER TABLE lims.meta_module OWNER TO postgres;

--
-- Name: TABLE meta_module; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_module IS 'Метаданные модулей';


--
-- Name: COLUMN meta_module.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module.id IS 'Идентификатор';


--
-- Name: COLUMN meta_module.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module.name IS 'Название';


--
-- Name: COLUMN meta_module.caption; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module.caption IS 'Заголовок';


--
-- Name: meta_module_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_module_id_seq OWNER TO postgres;

--
-- Name: meta_module_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_module_id_seq OWNED BY lims.meta_module.id;


--
-- Name: meta_module_privilege; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_module_privilege (
    id integer NOT NULL,
    module_fk integer NOT NULL,
    privilege_fk integer NOT NULL
);


ALTER TABLE lims.meta_module_privilege OWNER TO postgres;

--
-- Name: TABLE meta_module_privilege; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_module_privilege IS 'Метаданые привилегий модулей';


--
-- Name: COLUMN meta_module_privilege.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module_privilege.id IS 'Идентификатор';


--
-- Name: COLUMN meta_module_privilege.module_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module_privilege.module_fk IS 'Ключ модуля';


--
-- Name: COLUMN meta_module_privilege.privilege_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_module_privilege.privilege_fk IS 'Ключ привилегии';


--
-- Name: meta_module_privilege_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_module_privilege_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_module_privilege_id_seq OWNER TO postgres;

--
-- Name: meta_module_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_module_privilege_id_seq OWNED BY lims.meta_module_privilege.id;


--
-- Name: meta_privilege; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_privilege (
    id integer NOT NULL,
    name text NOT NULL,
    caption text,
    role_name text
);


ALTER TABLE lims.meta_privilege OWNER TO postgres;

--
-- Name: TABLE meta_privilege; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_privilege IS 'Метаданные привилегий';


--
-- Name: COLUMN meta_privilege.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_privilege.id IS 'Идентификатор';


--
-- Name: COLUMN meta_privilege.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_privilege.name IS 'Название';


--
-- Name: COLUMN meta_privilege.caption; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_privilege.caption IS 'Заголовок';


--
-- Name: COLUMN meta_privilege.role_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_privilege.role_name IS 'Роль базы данных';


--
-- Name: meta_privilege_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_privilege_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_privilege_id_seq OWNER TO postgres;

--
-- Name: meta_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_privilege_id_seq OWNED BY lims.meta_privilege.id;


--
-- Name: meta_report; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_report (
    id integer NOT NULL,
    name text NOT NULL,
    caption text NOT NULL,
    group_fk integer
);


ALTER TABLE lims.meta_report OWNER TO postgres;

--
-- Name: TABLE meta_report; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_report IS 'Метаданные отчетов';


--
-- Name: COLUMN meta_report.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_report.id IS 'Идентификатор';


--
-- Name: COLUMN meta_report.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_report.name IS 'Название';


--
-- Name: COLUMN meta_report.caption; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_report.caption IS 'Заголовок';


--
-- Name: COLUMN meta_report.group_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_report.group_fk IS 'Ключ группы';


--
-- Name: meta_report_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_report_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_report_id_seq OWNER TO postgres;

--
-- Name: meta_report_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_report_id_seq OWNED BY lims.meta_report.id;


--
-- Name: meta_script; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_script (
    id integer NOT NULL,
    model_fk integer NOT NULL,
    name text NOT NULL,
    version numeric DEFAULT 1 NOT NULL,
    text text NOT NULL,
    CONSTRAINT script_version_ck CHECK ((version > (1)::numeric))
);


ALTER TABLE lims.meta_script OWNER TO postgres;

--
-- Name: TABLE meta_script; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_script IS 'Метаданные скриптов';


--
-- Name: COLUMN meta_script.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_script.id IS 'Идентификатор';


--
-- Name: COLUMN meta_script.model_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_script.model_fk IS 'Ключ модели';


--
-- Name: COLUMN meta_script.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_script.name IS 'Название';


--
-- Name: COLUMN meta_script.version; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_script.version IS 'Версия';


--
-- Name: COLUMN meta_script.text; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_script.text IS 'Текст скрипта';


--
-- Name: meta_script_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_script_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_script_id_seq OWNER TO postgres;

--
-- Name: meta_script_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_script_id_seq OWNED BY lims.meta_script.id;


--
-- Name: meta_solution; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_solution (
    id integer NOT NULL,
    entity_fk integer NOT NULL,
    stage_fk integer NOT NULL,
    variant_fk integer NOT NULL,
    script_fk integer,
    option jsonb
);


ALTER TABLE lims.meta_solution OWNER TO postgres;

--
-- Name: TABLE meta_solution; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_solution IS 'Решения';


--
-- Name: COLUMN meta_solution.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.id IS 'Идентификатор';


--
-- Name: COLUMN meta_solution.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.entity_fk IS 'Ключ сущности';


--
-- Name: COLUMN meta_solution.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN meta_solution.variant_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.variant_fk IS 'Ключ варианта';


--
-- Name: COLUMN meta_solution.script_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.script_fk IS 'Ключ скрипта';


--
-- Name: COLUMN meta_solution.option; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_solution.option IS 'Настройки в формате JSON';


--
-- Name: meta_solution_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_solution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_solution_id_seq OWNER TO postgres;

--
-- Name: meta_solution_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_solution_id_seq OWNED BY lims.meta_solution.id;


--
-- Name: meta_variant; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_variant (
    id integer NOT NULL,
    model_fk integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE lims.meta_variant OWNER TO postgres;

--
-- Name: TABLE meta_variant; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_variant IS 'Метаданные вариантов моделей';


--
-- Name: COLUMN meta_variant.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant.id IS 'Идентификатор';


--
-- Name: COLUMN meta_variant.model_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant.model_fk IS 'Ключ модели';


--
-- Name: COLUMN meta_variant.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant.name IS 'Название';


--
-- Name: meta_variant_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_variant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.meta_variant_id_seq OWNER TO postgres;

--
-- Name: meta_variant_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_variant_id_seq OWNED BY lims.meta_variant.id;


--
-- Name: meta_variant_structure; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.meta_variant_structure (
    id bigint NOT NULL,
    variant_fk integer NOT NULL,
    item_fk integer NOT NULL,
    attribute_fk integer NOT NULL,
    equipment_fk integer,
    unit_fk integer,
    status integer,
    "precision" integer,
    CONSTRAINT variant_structure_precision_ck CHECK (("precision" >= 0)),
    CONSTRAINT variant_structure_status_ck CHECK ((status = ANY (ARRAY[0, 1, 2])))
);


ALTER TABLE lims.meta_variant_structure OWNER TO postgres;

--
-- Name: TABLE meta_variant_structure; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.meta_variant_structure IS 'Метаданные структур вариантов моделей';


--
-- Name: COLUMN meta_variant_structure.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.id IS 'Идентификатор';


--
-- Name: COLUMN meta_variant_structure.variant_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.variant_fk IS 'Ключ варианта';


--
-- Name: COLUMN meta_variant_structure.item_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.item_fk IS 'Ключ таблицы';


--
-- Name: COLUMN meta_variant_structure.attribute_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.attribute_fk IS 'Ключ атрибута';


--
-- Name: COLUMN meta_variant_structure.equipment_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.equipment_fk IS 'Ключ оборудования';


--
-- Name: COLUMN meta_variant_structure.unit_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.unit_fk IS 'Ключ единицы измерения';


--
-- Name: COLUMN meta_variant_structure.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure.status IS 'Устанавливаемый статус';


--
-- Name: COLUMN meta_variant_structure."precision"; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.meta_variant_structure."precision" IS 'Количество знаков при округлении';


--
-- Name: meta_variant_structure_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.meta_variant_structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.meta_variant_structure_id_seq OWNER TO postgres;

--
-- Name: meta_variant_structure_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.meta_variant_structure_id_seq OWNED BY lims.meta_variant_structure.id;


--
-- Name: mngt_department; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.mngt_department (
    id integer NOT NULL,
    name text NOT NULL,
    parent_fk integer,
    group_fk integer,
    city_fk integer,
    address text,
    phone text,
    status boolean DEFAULT true NOT NULL,
    CONSTRAINT department_parent_ck CHECK ((parent_fk <> id))
);


ALTER TABLE lims.mngt_department OWNER TO postgres;

--
-- Name: TABLE mngt_department; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.mngt_department IS 'Подразделения';


--
-- Name: COLUMN mngt_department.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.id IS 'Идентификатор';


--
-- Name: COLUMN mngt_department.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.name IS 'Название';


--
-- Name: COLUMN mngt_department.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.parent_fk IS 'Ключ родителя';


--
-- Name: COLUMN mngt_department.group_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.group_fk IS 'Ключ группы';


--
-- Name: COLUMN mngt_department.city_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.city_fk IS 'Ключ города';


--
-- Name: COLUMN mngt_department.address; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.address IS 'Адрес';


--
-- Name: COLUMN mngt_department.phone; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.phone IS 'Телефон';


--
-- Name: COLUMN mngt_department.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_department.status IS 'Статус';


--
-- Name: mngt_department_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.mngt_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.mngt_department_id_seq OWNER TO postgres;

--
-- Name: mngt_department_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.mngt_department_id_seq OWNED BY lims.mngt_department.id;


--
-- Name: mngt_material; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.mngt_material (
    id bigint NOT NULL,
    num integer NOT NULL,
    name text NOT NULL,
    note text,
    unit_fk integer NOT NULL,
    inventory_fk integer,
    status boolean DEFAULT true NOT NULL
);


ALTER TABLE lims.mngt_material OWNER TO postgres;

--
-- Name: TABLE mngt_material; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.mngt_material IS 'Справочник материалов';


--
-- Name: COLUMN mngt_material.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.id IS 'Идентификатор';


--
-- Name: COLUMN mngt_material.num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.num IS 'Инвентарный номер';


--
-- Name: COLUMN mngt_material.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.name IS 'Название';


--
-- Name: COLUMN mngt_material.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.note IS 'Описание';


--
-- Name: COLUMN mngt_material.unit_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.unit_fk IS 'Ключ единицы измерения';


--
-- Name: COLUMN mngt_material.inventory_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.inventory_fk IS 'Ключ инвентаря';


--
-- Name: COLUMN mngt_material.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_material.status IS 'Статус';


--
-- Name: mngt_material_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.mngt_material_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.mngt_material_id_seq OWNER TO postgres;

--
-- Name: mngt_material_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.mngt_material_id_seq OWNED BY lims.mngt_material.id;


--
-- Name: mngt_post; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.mngt_post (
    id integer NOT NULL,
    name text NOT NULL,
    parent_fk integer,
    group_fk integer,
    CONSTRAINT post_parent_ck CHECK ((parent_fk <> id))
);


ALTER TABLE lims.mngt_post OWNER TO postgres;

--
-- Name: TABLE mngt_post; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.mngt_post IS 'Должности';


--
-- Name: COLUMN mngt_post.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_post.id IS 'Идентификатор';


--
-- Name: COLUMN mngt_post.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_post.name IS 'Название';


--
-- Name: COLUMN mngt_post.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_post.parent_fk IS 'Ключ родителя';


--
-- Name: COLUMN mngt_post.group_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_post.group_fk IS 'Ключ группы';


--
-- Name: mngt_post_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.mngt_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.mngt_post_id_seq OWNER TO postgres;

--
-- Name: mngt_post_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.mngt_post_id_seq OWNED BY lims.mngt_post.id;


--
-- Name: mngt_work; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.mngt_work (
    id integer NOT NULL,
    name text NOT NULL,
    note text,
    decision_fk integer,
    status boolean DEFAULT true NOT NULL
);


ALTER TABLE lims.mngt_work OWNER TO postgres;

--
-- Name: TABLE mngt_work; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.mngt_work IS 'Справочник работ';


--
-- Name: COLUMN mngt_work.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_work.id IS 'Идентификатор';


--
-- Name: COLUMN mngt_work.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_work.name IS 'Название';


--
-- Name: COLUMN mngt_work.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_work.note IS 'Описание';


--
-- Name: COLUMN mngt_work.decision_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_work.decision_fk IS 'Ключ решения';


--
-- Name: COLUMN mngt_work.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_work.status IS 'Статус';


--
-- Name: mngt_work_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.mngt_work_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.mngt_work_id_seq OWNER TO postgres;

--
-- Name: mngt_work_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.mngt_work_id_seq OWNED BY lims.mngt_work.id;


--
-- Name: mngt_worker; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.mngt_worker (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    middle_name text,
    department_fk integer,
    post_fk integer,
    login text NOT NULL,
    initials character varying(4) NOT NULL,
    status boolean DEFAULT true NOT NULL
);


ALTER TABLE lims.mngt_worker OWNER TO postgres;

--
-- Name: TABLE mngt_worker; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.mngt_worker IS 'Работники';


--
-- Name: COLUMN mngt_worker.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.id IS 'Идентификатор';


--
-- Name: COLUMN mngt_worker.first_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.first_name IS 'Имя';


--
-- Name: COLUMN mngt_worker.last_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.last_name IS 'Фамилия';


--
-- Name: COLUMN mngt_worker.middle_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.middle_name IS 'Отчество';


--
-- Name: COLUMN mngt_worker.department_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.department_fk IS 'Ключ подразделения';


--
-- Name: COLUMN mngt_worker.post_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.post_fk IS 'Ключ должности';


--
-- Name: COLUMN mngt_worker.login; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.login IS 'Логин';


--
-- Name: COLUMN mngt_worker.initials; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.initials IS 'Инициалы';


--
-- Name: COLUMN mngt_worker.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.mngt_worker.status IS 'Статус';


--
-- Name: mngt_worker_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.mngt_worker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.mngt_worker_id_seq OWNER TO postgres;

--
-- Name: mngt_worker_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.mngt_worker_id_seq OWNED BY lims.mngt_worker.id;


--
-- Name: obj_collection; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.obj_collection (
    id bigint NOT NULL,
    collection_fk bigint NOT NULL,
    object_fk bigint NOT NULL,
    order_num integer NOT NULL,
    CONSTRAINT collection_order_num_ck CHECK ((order_num >= 0))
);


ALTER TABLE lims.obj_collection OWNER TO postgres;

--
-- Name: TABLE obj_collection; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.obj_collection IS 'Коллекции объектов';


--
-- Name: COLUMN obj_collection.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_collection.id IS 'Идентификатор';


--
-- Name: COLUMN obj_collection.collection_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_collection.collection_fk IS 'Ключ коллекции';


--
-- Name: COLUMN obj_collection.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_collection.object_fk IS 'Ключ объекта';


--
-- Name: COLUMN obj_collection.order_num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_collection.order_num IS 'Порядковый номер';


--
-- Name: obj_collection_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.obj_collection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.obj_collection_id_seq OWNER TO postgres;

--
-- Name: obj_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.obj_collection_id_seq OWNED BY lims.obj_collection.id;


--
-- Name: obj_entity; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.obj_entity (
    id integer NOT NULL,
    name text NOT NULL,
    table_name text NOT NULL
);


ALTER TABLE lims.obj_entity OWNER TO postgres;

--
-- Name: TABLE obj_entity; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.obj_entity IS 'Сущности объектов';


--
-- Name: COLUMN obj_entity.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_entity.id IS 'Идентификатор';


--
-- Name: COLUMN obj_entity.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_entity.name IS 'Название';


--
-- Name: COLUMN obj_entity.table_name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_entity.table_name IS 'Имя таблицы в БД';


--
-- Name: obj_entity_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.obj_entity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.obj_entity_id_seq OWNER TO postgres;

--
-- Name: obj_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.obj_entity_id_seq OWNED BY lims.obj_entity.id;


--
-- Name: obj_main; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.obj_main (
    id bigint NOT NULL,
    entity_fk integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE lims.obj_main OWNER TO postgres;

--
-- Name: TABLE obj_main; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.obj_main IS 'Объекты (супертип)';


--
-- Name: COLUMN obj_main.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_main.id IS 'Идентификатор';


--
-- Name: COLUMN obj_main.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_main.entity_fk IS 'Ключ сущности';


--
-- Name: COLUMN obj_main.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_main.name IS 'Название';


--
-- Name: obj_main_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.obj_main_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.obj_main_id_seq OWNER TO postgres;

--
-- Name: obj_main_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.obj_main_id_seq OWNED BY lims.obj_main.id;


--
-- Name: obj_parent; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.obj_parent (
    id bigint NOT NULL,
    object_fk bigint NOT NULL,
    parent_fk bigint NOT NULL,
    part numeric DEFAULT 1 NOT NULL,
    CONSTRAINT parent_part_ck CHECK (((part > (0)::numeric) AND (part <= (1)::numeric)))
);


ALTER TABLE lims.obj_parent OWNER TO postgres;

--
-- Name: TABLE obj_parent; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.obj_parent IS 'Родители объектов';


--
-- Name: COLUMN obj_parent.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_parent.id IS 'Идентификатор';


--
-- Name: COLUMN obj_parent.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_parent.object_fk IS 'Ключ объекта';


--
-- Name: COLUMN obj_parent.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_parent.parent_fk IS 'Ключ родительского объекта';


--
-- Name: COLUMN obj_parent.part; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.obj_parent.part IS 'Вклад родительского объекта';


--
-- Name: obj_parent_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.obj_parent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.obj_parent_id_seq OWNER TO postgres;

--
-- Name: obj_parent_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.obj_parent_id_seq OWNED BY lims.obj_parent.id;


--
-- Name: prcs_plan; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.prcs_plan (
    id bigint NOT NULL,
    object_fk bigint NOT NULL,
    stage_fk integer NOT NULL,
    value boolean DEFAULT false NOT NULL,
    status boolean DEFAULT false NOT NULL
);


ALTER TABLE lims.prcs_plan OWNER TO postgres;

--
-- Name: TABLE prcs_plan; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.prcs_plan IS 'Задания (план)';


--
-- Name: COLUMN prcs_plan.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_plan.id IS 'Идентификатор';


--
-- Name: COLUMN prcs_plan.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_plan.object_fk IS 'Ключ объекта';


--
-- Name: COLUMN prcs_plan.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_plan.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN prcs_plan.value; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_plan.value IS 'Значение планирования';


--
-- Name: COLUMN prcs_plan.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_plan.status IS 'Статус';


--
-- Name: prcs_plan_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.prcs_plan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.prcs_plan_id_seq OWNER TO postgres;

--
-- Name: prcs_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.prcs_plan_id_seq OWNED BY lims.prcs_plan.id;


--
-- Name: prcs_stage; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.prcs_stage (
    id integer NOT NULL,
    name text NOT NULL,
    abbreviation text,
    department_fk integer NOT NULL
);


ALTER TABLE lims.prcs_stage OWNER TO postgres;

--
-- Name: TABLE prcs_stage; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.prcs_stage IS 'Этапы';


--
-- Name: COLUMN prcs_stage.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage.id IS 'Идентификатор';


--
-- Name: COLUMN prcs_stage.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage.name IS 'Название';


--
-- Name: COLUMN prcs_stage.abbreviation; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage.abbreviation IS 'Аббревиатура';


--
-- Name: COLUMN prcs_stage.department_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage.department_fk IS 'Ключ подразделения';


--
-- Name: prcs_stage_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.prcs_stage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.prcs_stage_id_seq OWNER TO postgres;

--
-- Name: prcs_stage_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.prcs_stage_id_seq OWNED BY lims.prcs_stage.id;


--
-- Name: prcs_stage_prerequisite; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.prcs_stage_prerequisite (
    id integer NOT NULL,
    stage_fk integer NOT NULL,
    prerequisite_fk integer NOT NULL,
    CONSTRAINT stage_prerequisite_ck CHECK ((stage_fk <> prerequisite_fk))
);


ALTER TABLE lims.prcs_stage_prerequisite OWNER TO postgres;

--
-- Name: TABLE prcs_stage_prerequisite; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.prcs_stage_prerequisite IS 'Пререквизиты этапов';


--
-- Name: COLUMN prcs_stage_prerequisite.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_prerequisite.id IS 'Идентификатор';


--
-- Name: COLUMN prcs_stage_prerequisite.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_prerequisite.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN prcs_stage_prerequisite.prerequisite_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_prerequisite.prerequisite_fk IS 'Ключ предшествующего этапа';


--
-- Name: prcs_stage_prerequisite_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.prcs_stage_prerequisite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.prcs_stage_prerequisite_id_seq OWNER TO postgres;

--
-- Name: prcs_stage_prerequisite_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.prcs_stage_prerequisite_id_seq OWNED BY lims.prcs_stage_prerequisite.id;


--
-- Name: prcs_stage_sequence; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.prcs_stage_sequence (
    id integer NOT NULL,
    sequence_fk integer NOT NULL,
    stage_fk integer NOT NULL,
    order_num integer NOT NULL,
    CONSTRAINT stage_sequence_order_num_ck CHECK ((order_num >= 0))
);


ALTER TABLE lims.prcs_stage_sequence OWNER TO postgres;

--
-- Name: TABLE prcs_stage_sequence; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.prcs_stage_sequence IS 'Последовательности этапов';


--
-- Name: COLUMN prcs_stage_sequence.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_sequence.id IS 'Идентификатор';


--
-- Name: COLUMN prcs_stage_sequence.sequence_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_sequence.sequence_fk IS 'Ключ последовательности';


--
-- Name: COLUMN prcs_stage_sequence.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_sequence.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN prcs_stage_sequence.order_num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_stage_sequence.order_num IS 'Порядковый номер';


--
-- Name: prcs_stage_sequence_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.prcs_stage_sequence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.prcs_stage_sequence_id_seq OWNER TO postgres;

--
-- Name: prcs_stage_sequence_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.prcs_stage_sequence_id_seq OWNED BY lims.prcs_stage_sequence.id;


--
-- Name: prcs_task; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.prcs_task (
    id bigint NOT NULL,
    plan_fk bigint,
    stage_fk integer NOT NULL,
    object_fk bigint NOT NULL,
    order_fk bigint,
    deadline date,
    priority integer DEFAULT 1 NOT NULL,
    date_begin date,
    date_end date,
    status integer DEFAULT 0 NOT NULL,
    script_fk integer,
    note text,
    CONSTRAINT task_date_begin_end_ck CHECK ((date_begin <= date_end)),
    CONSTRAINT task_status_ck CHECK ((status = ANY (ARRAY[0, 1, 2]))),
    CONSTRAINT task_status_priority_ck CHECK (((priority >= 1) AND (priority <= 5)))
);


ALTER TABLE lims.prcs_task OWNER TO postgres;

--
-- Name: TABLE prcs_task; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.prcs_task IS 'Задания (факт)';


--
-- Name: COLUMN prcs_task.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.id IS 'Идентификатор';


--
-- Name: COLUMN prcs_task.plan_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.plan_fk IS 'Ключ плана';


--
-- Name: COLUMN prcs_task.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN prcs_task.object_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.object_fk IS 'Ключ объекта';


--
-- Name: COLUMN prcs_task.order_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.order_fk IS 'Ключ заказа';


--
-- Name: COLUMN prcs_task.deadline; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.deadline IS 'Крайний срок выполнения';


--
-- Name: COLUMN prcs_task.priority; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.priority IS 'Приоритетность выполения';


--
-- Name: COLUMN prcs_task.date_begin; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.date_begin IS 'Реальная дата начала';


--
-- Name: COLUMN prcs_task.date_end; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.date_end IS 'Реальная дата окончания';


--
-- Name: COLUMN prcs_task.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.status IS 'Статус';


--
-- Name: COLUMN prcs_task.script_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.script_fk IS 'Ключ скрипта выполнения';


--
-- Name: COLUMN prcs_task.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.prcs_task.note IS 'Примечание';


--
-- Name: prcs_task_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.prcs_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.prcs_task_id_seq OWNER TO postgres;

--
-- Name: prcs_task_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.prcs_task_id_seq OWNED BY lims.prcs_task.id;


--
-- Name: result_main; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.result_main (
    id bigint NOT NULL,
    task_fk bigint NOT NULL,
    item_fk integer NOT NULL,
    attribute_fk integer NOT NULL,
    row_id bigint,
    value_num numeric,
    value_dict integer,
    value_date date,
    value_str text,
    unit_fk integer,
    apparatus_fk integer,
    status integer NOT NULL,
    CONSTRAINT result_status_ck CHECK ((status = ANY (ARRAY[0, 1, 2])))
);


ALTER TABLE lims.result_main OWNER TO postgres;

--
-- Name: TABLE result_main; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.result_main IS 'Результаты';


--
-- Name: COLUMN result_main.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.id IS 'Идентификатор';


--
-- Name: COLUMN result_main.task_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.task_fk IS 'Ключ задания';


--
-- Name: COLUMN result_main.item_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.item_fk IS 'Ключ таблицы';


--
-- Name: COLUMN result_main.attribute_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.attribute_fk IS 'Ключ атрибута';


--
-- Name: COLUMN result_main.row_id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.row_id IS 'Идентификатор строки';


--
-- Name: COLUMN result_main.value_num; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.value_num IS 'Результат число';


--
-- Name: COLUMN result_main.value_dict; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.value_dict IS 'Результат ссылка на справочник';


--
-- Name: COLUMN result_main.value_date; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.value_date IS 'Результат дата';


--
-- Name: COLUMN result_main.value_str; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.value_str IS 'Результат строка';


--
-- Name: COLUMN result_main.unit_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.unit_fk IS 'Ключ единицы измерения';


--
-- Name: COLUMN result_main.apparatus_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.apparatus_fk IS 'Ключ прибора';


--
-- Name: COLUMN result_main.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_main.status IS 'Статус';


--
-- Name: result_main_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.result_main_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.result_main_id_seq OWNER TO postgres;

--
-- Name: result_main_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.result_main_id_seq OWNED BY lims.result_main.id;


--
-- Name: result_main_row_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.result_main_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.result_main_row_id_seq OWNER TO postgres;

--
-- Name: result_material; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.result_material (
    id bigint NOT NULL,
    task_fk bigint NOT NULL,
    material_fk bigint NOT NULL,
    volume numeric DEFAULT 1 NOT NULL,
    unit_fk integer NOT NULL,
    CONSTRAINT result_material_volume_ck CHECK ((volume > (0)::numeric))
);


ALTER TABLE lims.result_material OWNER TO postgres;

--
-- Name: TABLE result_material; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.result_material IS 'Потраченные материалы';


--
-- Name: COLUMN result_material.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_material.id IS 'Идентификатор';


--
-- Name: COLUMN result_material.task_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_material.task_fk IS 'Ключ задания';


--
-- Name: COLUMN result_material.material_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_material.material_fk IS 'Ключ материала';


--
-- Name: COLUMN result_material.volume; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_material.volume IS 'Объем материала';


--
-- Name: COLUMN result_material.unit_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_material.unit_fk IS 'Ключ единицы измерения';


--
-- Name: result_material_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.result_material_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.result_material_id_seq OWNER TO postgres;

--
-- Name: result_material_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.result_material_id_seq OWNED BY lims.result_material.id;


--
-- Name: result_work; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.result_work (
    id bigint NOT NULL,
    task_fk bigint NOT NULL,
    work_fk integer NOT NULL,
    volume numeric DEFAULT 1 NOT NULL,
    worker_fk integer NOT NULL,
    CONSTRAINT result_work_volume_ck CHECK ((volume > (0)::numeric))
);


ALTER TABLE lims.result_work OWNER TO postgres;

--
-- Name: TABLE result_work; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.result_work IS 'Выполненные работы';


--
-- Name: COLUMN result_work.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_work.id IS 'Идентификатор';


--
-- Name: COLUMN result_work.task_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_work.task_fk IS 'Ключ задания';


--
-- Name: COLUMN result_work.work_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_work.work_fk IS 'Ключ работы';


--
-- Name: COLUMN result_work.volume; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_work.volume IS 'Объем работы';


--
-- Name: COLUMN result_work.worker_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.result_work.worker_fk IS 'Ключ работника';


--
-- Name: result_work_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.result_work_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 4294967294
    CACHE 1;


ALTER TABLE lims.result_work_id_seq OWNER TO postgres;

--
-- Name: result_work_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.result_work_id_seq OWNED BY lims.result_work.id;


--
-- Name: tag_main; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tag_main (
    id integer DEFAULT nextval('lims.mngt_work_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    note text,
    status boolean DEFAULT true NOT NULL,
    type text NOT NULL,
    CONSTRAINT tag_type_ck CHECK ((type = ANY (ARRAY['CLIENT'::text, 'OBJECT'::text, 'ORDER'::text, 'TASK'::text])))
);


ALTER TABLE lims.tag_main OWNER TO postgres;

--
-- Name: TABLE tag_main; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tag_main IS 'Таги';


--
-- Name: COLUMN tag_main.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_main.id IS 'Идентификатор';


--
-- Name: COLUMN tag_main.name; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_main.name IS 'Название';


--
-- Name: COLUMN tag_main.note; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_main.note IS 'Описание';


--
-- Name: COLUMN tag_main.status; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_main.status IS 'Статус';


--
-- Name: COLUMN tag_main.type; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tag_main.type IS 'Тип';


--
-- Name: tag_main_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tag_main_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tag_main_id_seq OWNER TO postgres;

--
-- Name: tag_main_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tag_main_id_seq OWNED BY lims.tag_main.id;


--
-- Name: tmpl_collection_entity; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_collection_entity (
    id integer NOT NULL,
    collection_fk integer NOT NULL,
    entity_fk integer NOT NULL,
    CONSTRAINT collection_entity_ck CHECK ((collection_fk <> entity_fk))
);


ALTER TABLE lims.tmpl_collection_entity OWNER TO postgres;

--
-- Name: TABLE tmpl_collection_entity; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_collection_entity IS 'Доступные типы сущностей для типов коллекций';


--
-- Name: COLUMN tmpl_collection_entity.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_collection_entity.id IS 'Идентификатор';


--
-- Name: COLUMN tmpl_collection_entity.collection_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_collection_entity.collection_fk IS 'Ключ сущности коллекции';


--
-- Name: COLUMN tmpl_collection_entity.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_collection_entity.entity_fk IS 'Ключ сущности';


--
-- Name: tmpl_collection_entity_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_collection_entity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_collection_entity_id_seq OWNER TO postgres;

--
-- Name: tmpl_collection_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_collection_entity_id_seq OWNED BY lims.tmpl_collection_entity.id;


--
-- Name: tmpl_entity_parent; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_entity_parent (
    id integer NOT NULL,
    entity_fk integer NOT NULL,
    parent_fk integer NOT NULL,
    CONSTRAINT entity_parent_ck CHECK ((parent_fk <> entity_fk))
);


ALTER TABLE lims.tmpl_entity_parent OWNER TO postgres;

--
-- Name: TABLE tmpl_entity_parent; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_entity_parent IS 'Разрешенные родители сущностей объектов';


--
-- Name: COLUMN tmpl_entity_parent.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_parent.id IS 'Идентификатор';


--
-- Name: COLUMN tmpl_entity_parent.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_parent.entity_fk IS 'Ключ сущности';


--
-- Name: COLUMN tmpl_entity_parent.parent_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_parent.parent_fk IS 'Ключ родительской сущности';


--
-- Name: tmpl_entity_parent_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_entity_parent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_entity_parent_id_seq OWNER TO postgres;

--
-- Name: tmpl_entity_parent_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_entity_parent_id_seq OWNED BY lims.tmpl_entity_parent.id;


--
-- Name: tmpl_entity_stage; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_entity_stage (
    id integer NOT NULL,
    entity_fk integer NOT NULL,
    stage_fk integer NOT NULL
);


ALTER TABLE lims.tmpl_entity_stage OWNER TO postgres;

--
-- Name: TABLE tmpl_entity_stage; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_entity_stage IS 'Шаблоны доступных этапов планирования для сущностей';


--
-- Name: COLUMN tmpl_entity_stage.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_stage.id IS 'Уникальный ижентификатор';


--
-- Name: COLUMN tmpl_entity_stage.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_stage.entity_fk IS 'Ключ сущности';


--
-- Name: COLUMN tmpl_entity_stage.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_stage.stage_fk IS 'Ключ этапа';


--
-- Name: tmpl_entity_stage_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_entity_stage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_entity_stage_id_seq OWNER TO postgres;

--
-- Name: tmpl_entity_stage_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_entity_stage_id_seq OWNED BY lims.tmpl_entity_stage.id;


--
-- Name: tmpl_entity_tag; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_entity_tag (
    id integer NOT NULL,
    entity_fk integer NOT NULL,
    tag_fk integer NOT NULL
);


ALTER TABLE lims.tmpl_entity_tag OWNER TO postgres;

--
-- Name: TABLE tmpl_entity_tag; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_entity_tag IS 'Доступные таги для сущностей';


--
-- Name: COLUMN tmpl_entity_tag.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_tag.id IS 'Идентификатор';


--
-- Name: COLUMN tmpl_entity_tag.entity_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_tag.entity_fk IS 'Ключ сущности';


--
-- Name: COLUMN tmpl_entity_tag.tag_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_entity_tag.tag_fk IS 'Ключ тага';


--
-- Name: tmpl_entity_tag_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_entity_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_entity_tag_id_seq OWNER TO postgres;

--
-- Name: tmpl_entity_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_entity_tag_id_seq OWNED BY lims.tmpl_entity_tag.id;


--
-- Name: tmpl_stage_decision; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_stage_decision (
    id integer NOT NULL,
    stage_fk integer NOT NULL,
    decision_fk integer NOT NULL
);


ALTER TABLE lims.tmpl_stage_decision OWNER TO postgres;

--
-- Name: TABLE tmpl_stage_decision; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_stage_decision IS 'Доступные группы работ для этапов';


--
-- Name: COLUMN tmpl_stage_decision.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_decision.id IS 'Идентификатор';


--
-- Name: COLUMN tmpl_stage_decision.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_decision.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN tmpl_stage_decision.decision_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_decision.decision_fk IS 'Ключ группы работ';


--
-- Name: tmpl_stage_decision_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_stage_decision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_stage_decision_id_seq OWNER TO postgres;

--
-- Name: tmpl_stage_decision_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_stage_decision_id_seq OWNED BY lims.tmpl_stage_decision.id;


--
-- Name: tmpl_stage_inventory; Type: TABLE; Schema: lims; Owner: postgres
--

CREATE TABLE lims.tmpl_stage_inventory (
    id integer NOT NULL,
    stage_fk integer NOT NULL,
    inventory_fk integer NOT NULL
);


ALTER TABLE lims.tmpl_stage_inventory OWNER TO postgres;

--
-- Name: TABLE tmpl_stage_inventory; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON TABLE lims.tmpl_stage_inventory IS 'Доступные группы материалов для этапов';


--
-- Name: COLUMN tmpl_stage_inventory.id; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_inventory.id IS 'Идентификатор';


--
-- Name: COLUMN tmpl_stage_inventory.stage_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_inventory.stage_fk IS 'Ключ этапа';


--
-- Name: COLUMN tmpl_stage_inventory.inventory_fk; Type: COMMENT; Schema: lims; Owner: postgres
--

COMMENT ON COLUMN lims.tmpl_stage_inventory.inventory_fk IS 'Ключ группы материалов';


--
-- Name: tmpl_stage_inventory_id_seq; Type: SEQUENCE; Schema: lims; Owner: postgres
--

CREATE SEQUENCE lims.tmpl_stage_inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE lims.tmpl_stage_inventory_id_seq OWNER TO postgres;

--
-- Name: tmpl_stage_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: lims; Owner: postgres
--

ALTER SEQUENCE lims.tmpl_stage_inventory_id_seq OWNED BY lims.tmpl_stage_inventory.id;


--
-- Name: crm_client id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_client ALTER COLUMN id SET DEFAULT nextval('lims.crm_client_id_seq'::regclass);


--
-- Name: crm_material_price id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price ALTER COLUMN id SET DEFAULT nextval('lims.crm_material_price_id_seq'::regclass);


--
-- Name: crm_order id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_order ALTER COLUMN id SET DEFAULT nextval('lims.crm_order_id_seq'::regclass);


--
-- Name: crm_work_price id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_work_price ALTER COLUMN id SET DEFAULT nextval('lims.crm_work_price_id_seq'::regclass);


--
-- Name: dict_city id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_city ALTER COLUMN id SET DEFAULT nextval('lims.dict_city_id_seq'::regclass);


--
-- Name: dict_currency id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_currency ALTER COLUMN id SET DEFAULT nextval('lims.dict_currency_id_seq'::regclass);


--
-- Name: dict_decision id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_decision ALTER COLUMN id SET DEFAULT nextval('lims.dict_decision_id_seq'::regclass);


--
-- Name: dict_inventory id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_inventory ALTER COLUMN id SET DEFAULT nextval('lims.dict_inventory_id_seq'::regclass);


--
-- Name: dict_main id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_main ALTER COLUMN id SET DEFAULT nextval('lims.dict_main_id_seq'::regclass);


--
-- Name: dict_sequence id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_sequence ALTER COLUMN id SET DEFAULT nextval('lims.dict_sequence_id_seq'::regclass);


--
-- Name: dict_unit id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_unit ALTER COLUMN id SET DEFAULT nextval('lims.dict_unit_id_seq'::regclass);


--
-- Name: eqp_apparatus id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_apparatus ALTER COLUMN id SET DEFAULT nextval('lims.eqp_apparatus_id_seq'::regclass);


--
-- Name: eqp_equipment id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_equipment ALTER COLUMN id SET DEFAULT nextval('lims.eqp_equipment_id_seq'::regclass);


--
-- Name: file_main id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_main ALTER COLUMN id SET DEFAULT nextval('lims.file_main_id_seq'::regclass);


--
-- Name: grant_worker_privilege id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_privilege ALTER COLUMN id SET DEFAULT nextval('lims.grant_worker_privilege_id_seq'::regclass);


--
-- Name: grant_worker_report id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_report ALTER COLUMN id SET DEFAULT nextval('lims.grant_worker_report_id_seq'::regclass);


--
-- Name: grant_worker_stage id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_stage ALTER COLUMN id SET DEFAULT nextval('lims.grant_worker_stage_id_seq'::regclass);


--
-- Name: meta_attribute id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_attribute ALTER COLUMN id SET DEFAULT nextval('lims.meta_attribute_id_seq'::regclass);


--
-- Name: meta_item id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item ALTER COLUMN id SET DEFAULT nextval('lims.meta_item_id_seq'::regclass);


--
-- Name: meta_item_attribute id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute ALTER COLUMN id SET DEFAULT nextval('lims.meta_item_attribute_id_seq'::regclass);


--
-- Name: meta_model id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model ALTER COLUMN id SET DEFAULT nextval('lims.meta_model_id_seq'::regclass);


--
-- Name: meta_model_item id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model_item ALTER COLUMN id SET DEFAULT nextval('lims.meta_model_item_id_seq'::regclass);


--
-- Name: meta_module id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module ALTER COLUMN id SET DEFAULT nextval('lims.meta_module_id_seq'::regclass);


--
-- Name: meta_module_privilege id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module_privilege ALTER COLUMN id SET DEFAULT nextval('lims.meta_module_privilege_id_seq'::regclass);


--
-- Name: meta_privilege id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_privilege ALTER COLUMN id SET DEFAULT nextval('lims.meta_privilege_id_seq'::regclass);


--
-- Name: meta_report id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_report ALTER COLUMN id SET DEFAULT nextval('lims.meta_report_id_seq'::regclass);


--
-- Name: meta_script id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_script ALTER COLUMN id SET DEFAULT nextval('lims.meta_script_id_seq'::regclass);


--
-- Name: meta_solution id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution ALTER COLUMN id SET DEFAULT nextval('lims.meta_solution_id_seq'::regclass);


--
-- Name: meta_variant id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant ALTER COLUMN id SET DEFAULT nextval('lims.meta_variant_id_seq'::regclass);


--
-- Name: meta_variant_structure id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure ALTER COLUMN id SET DEFAULT nextval('lims.meta_variant_structure_id_seq'::regclass);


--
-- Name: mngt_department id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department ALTER COLUMN id SET DEFAULT nextval('lims.mngt_department_id_seq'::regclass);


--
-- Name: mngt_material id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_material ALTER COLUMN id SET DEFAULT nextval('lims.mngt_material_id_seq'::regclass);


--
-- Name: mngt_post id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_post ALTER COLUMN id SET DEFAULT nextval('lims.mngt_post_id_seq'::regclass);


--
-- Name: mngt_work id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_work ALTER COLUMN id SET DEFAULT nextval('lims.mngt_work_id_seq'::regclass);


--
-- Name: mngt_worker id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_worker ALTER COLUMN id SET DEFAULT nextval('lims.mngt_worker_id_seq'::regclass);


--
-- Name: obj_collection id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection ALTER COLUMN id SET DEFAULT nextval('lims.obj_collection_id_seq'::regclass);


--
-- Name: obj_entity id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_entity ALTER COLUMN id SET DEFAULT nextval('lims.obj_entity_id_seq'::regclass);


--
-- Name: obj_main id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_main ALTER COLUMN id SET DEFAULT nextval('lims.obj_main_id_seq'::regclass);


--
-- Name: obj_parent id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_parent ALTER COLUMN id SET DEFAULT nextval('lims.obj_parent_id_seq'::regclass);


--
-- Name: prcs_plan id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_plan ALTER COLUMN id SET DEFAULT nextval('lims.prcs_plan_id_seq'::regclass);


--
-- Name: prcs_stage id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage ALTER COLUMN id SET DEFAULT nextval('lims.prcs_stage_id_seq'::regclass);


--
-- Name: prcs_stage_prerequisite id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_prerequisite ALTER COLUMN id SET DEFAULT nextval('lims.prcs_stage_prerequisite_id_seq'::regclass);


--
-- Name: prcs_stage_sequence id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence ALTER COLUMN id SET DEFAULT nextval('lims.prcs_stage_sequence_id_seq'::regclass);


--
-- Name: prcs_task id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task ALTER COLUMN id SET DEFAULT nextval('lims.prcs_task_id_seq'::regclass);


--
-- Name: result_main id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main ALTER COLUMN id SET DEFAULT nextval('lims.result_main_id_seq'::regclass);


--
-- Name: result_material id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material ALTER COLUMN id SET DEFAULT nextval('lims.result_material_id_seq'::regclass);


--
-- Name: result_work id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work ALTER COLUMN id SET DEFAULT nextval('lims.result_work_id_seq'::regclass);


--
-- Name: tag_object id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_object ALTER COLUMN id SET DEFAULT nextval('lims.tag_object_id_seq'::regclass);


--
-- Name: tag_order id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_order ALTER COLUMN id SET DEFAULT nextval('lims.tag_order_id_seq'::regclass);


--
-- Name: tag_task id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_task ALTER COLUMN id SET DEFAULT nextval('lims.tag_task_id_seq'::regclass);


--
-- Name: tmpl_collection_entity id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_collection_entity ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_collection_entity_id_seq'::regclass);


--
-- Name: tmpl_entity_parent id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_parent ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_entity_parent_id_seq'::regclass);


--
-- Name: tmpl_entity_stage id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_stage ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_entity_stage_id_seq'::regclass);


--
-- Name: tmpl_entity_tag id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_tag ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_entity_tag_id_seq'::regclass);


--
-- Name: tmpl_stage_decision id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_decision ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_stage_decision_id_seq'::regclass);


--
-- Name: tmpl_stage_inventory id; Type: DEFAULT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_inventory ALTER COLUMN id SET DEFAULT nextval('lims.tmpl_stage_inventory_id_seq'::regclass);


--
-- Data for Name: crm_client; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_client (id, city_fk, address, phone, email, status, type) FROM stdin;
\.
COPY lims.crm_client (id, city_fk, address, phone, email, status, type) FROM '$$PATH$$/3848.dat';

--
-- Data for Name: crm_company; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_company (id_fk, name) FROM stdin;
\.
COPY lims.crm_company (id_fk, name) FROM '$$PATH$$/3850.dat';

--
-- Data for Name: crm_material_price; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_material_price (id, material_fk, price, currency_fk, volume, unit_fk) FROM stdin;
\.
COPY lims.crm_material_price (id, material_fk, price, currency_fk, volume, unit_fk) FROM '$$PATH$$/3851.dat';

--
-- Data for Name: crm_order; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_order (id, client_fk, name, manager_fk, date_contract, note, status) FROM stdin;
\.
COPY lims.crm_order (id, client_fk, name, manager_fk, date_contract, note, status) FROM '$$PATH$$/3853.dat';

--
-- Data for Name: crm_person; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_person (id_fk, first_name, last_name, middle_name) FROM stdin;
\.
COPY lims.crm_person (id_fk, first_name, last_name, middle_name) FROM '$$PATH$$/3855.dat';

--
-- Data for Name: crm_work_price; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.crm_work_price (id, work_fk, price, currency_fk, volume) FROM stdin;
\.
COPY lims.crm_work_price (id, work_fk, price, currency_fk, volume) FROM '$$PATH$$/3856.dat';

--
-- Data for Name: dict_city; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_city (id, name) FROM stdin;
\.
COPY lims.dict_city (id, name) FROM '$$PATH$$/3858.dat';

--
-- Data for Name: dict_currency; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_currency (id, name, symbol) FROM stdin;
\.
COPY lims.dict_currency (id, name, symbol) FROM '$$PATH$$/3860.dat';

--
-- Data for Name: dict_decision; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_decision (id, name, note, parent_fk) FROM stdin;
\.
COPY lims.dict_decision (id, name, note, parent_fk) FROM '$$PATH$$/3862.dat';

--
-- Data for Name: dict_inventory; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_inventory (id, name, note, parent_fk) FROM stdin;
\.
COPY lims.dict_inventory (id, name, note, parent_fk) FROM '$$PATH$$/3864.dat';

--
-- Data for Name: dict_main; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_main (id, name, note, parent_fk, order_num) FROM stdin;
\.
COPY lims.dict_main (id, name, note, parent_fk, order_num) FROM '$$PATH$$/3866.dat';

--
-- Data for Name: dict_sequence; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_sequence (id, name, department_fk) FROM stdin;
\.
COPY lims.dict_sequence (id, name, department_fk) FROM '$$PATH$$/3868.dat';

--
-- Data for Name: dict_unit; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.dict_unit (id, name, symbol) FROM stdin;
\.
COPY lims.dict_unit (id, name, symbol) FROM '$$PATH$$/3870.dat';

--
-- Data for Name: eqp_apparatus; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.eqp_apparatus (id, equipment_fk, department_fk, num, name, status) FROM stdin;
\.
COPY lims.eqp_apparatus (id, equipment_fk, department_fk, num, name, status) FROM '$$PATH$$/3872.dat';

--
-- Data for Name: eqp_equipment; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.eqp_equipment (id, group_fk, name, note) FROM stdin;
\.
COPY lims.eqp_equipment (id, group_fk, name, note) FROM '$$PATH$$/3874.dat';

--
-- Data for Name: file_client; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.file_client (id, file_fk, client_fk) FROM stdin;
\.
COPY lims.file_client (id, file_fk, client_fk) FROM '$$PATH$$/3878.dat';

--
-- Data for Name: file_main; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.file_main (id, name, extension, group_fk, thumbnail, file_size, md5, file_path, status) FROM stdin;
\.
COPY lims.file_main (id, name, extension, group_fk, thumbnail, file_size, md5, file_path, status) FROM '$$PATH$$/3880.dat';

--
-- Data for Name: file_object; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.file_object (id, file_fk, object_fk) FROM stdin;
\.
COPY lims.file_object (id, file_fk, object_fk) FROM '$$PATH$$/3884.dat';

--
-- Data for Name: file_order; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.file_order (id, file_fk, order_fk) FROM stdin;
\.
COPY lims.file_order (id, file_fk, order_fk) FROM '$$PATH$$/3888.dat';

--
-- Data for Name: file_task; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.file_task (id, file_fk, task_fk) FROM stdin;
\.
COPY lims.file_task (id, file_fk, task_fk) FROM '$$PATH$$/3892.dat';

--
-- Data for Name: grant_worker_privilege; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.grant_worker_privilege (id, worker_fk, module_privilege_fk) FROM stdin;
\.
COPY lims.grant_worker_privilege (id, worker_fk, module_privilege_fk) FROM '$$PATH$$/3894.dat';

--
-- Data for Name: grant_worker_report; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.grant_worker_report (id, worker_fk, report_fk) FROM stdin;
\.
COPY lims.grant_worker_report (id, worker_fk, report_fk) FROM '$$PATH$$/3896.dat';

--
-- Data for Name: grant_worker_stage; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.grant_worker_stage (id, worker_fk, stage_fk, access_view, access_execute, access_manage) FROM stdin;
\.
COPY lims.grant_worker_stage (id, worker_fk, stage_fk, access_view, access_execute, access_manage) FROM '$$PATH$$/3898.dat';

--
-- Data for Name: meta_attribute; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_attribute (id, name, caption, type) FROM stdin;
\.
COPY lims.meta_attribute (id, name, caption, type) FROM '$$PATH$$/3900.dat';

--
-- Data for Name: meta_item; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_item (id, name, order_attribute_fk, caption, type) FROM stdin;
\.
COPY lims.meta_item (id, name, order_attribute_fk, caption, type) FROM '$$PATH$$/3902.dat';

--
-- Data for Name: meta_item_attribute; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_item_attribute (id, item_fk, attribute_fk, order_num) FROM stdin;
\.
COPY lims.meta_item_attribute (id, item_fk, attribute_fk, order_num) FROM '$$PATH$$/3903.dat';

--
-- Data for Name: meta_model; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_model (id, name, note) FROM stdin;
\.
COPY lims.meta_model (id, name, note) FROM '$$PATH$$/3906.dat';

--
-- Data for Name: meta_model_item; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_model_item (id, model_fk, item_fk) FROM stdin;
\.
COPY lims.meta_model_item (id, model_fk, item_fk) FROM '$$PATH$$/3908.dat';

--
-- Data for Name: meta_module; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_module (id, name, caption) FROM stdin;
\.
COPY lims.meta_module (id, name, caption) FROM '$$PATH$$/3910.dat';

--
-- Data for Name: meta_module_privilege; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_module_privilege (id, module_fk, privilege_fk) FROM stdin;
\.
COPY lims.meta_module_privilege (id, module_fk, privilege_fk) FROM '$$PATH$$/3912.dat';

--
-- Data for Name: meta_privilege; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_privilege (id, name, caption, role_name) FROM stdin;
\.
COPY lims.meta_privilege (id, name, caption, role_name) FROM '$$PATH$$/3914.dat';

--
-- Data for Name: meta_report; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_report (id, name, caption, group_fk) FROM stdin;
\.
COPY lims.meta_report (id, name, caption, group_fk) FROM '$$PATH$$/3916.dat';

--
-- Data for Name: meta_script; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_script (id, model_fk, name, version, text) FROM stdin;
\.
COPY lims.meta_script (id, model_fk, name, version, text) FROM '$$PATH$$/3918.dat';

--
-- Data for Name: meta_solution; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_solution (id, entity_fk, stage_fk, variant_fk, script_fk, option) FROM stdin;
\.
COPY lims.meta_solution (id, entity_fk, stage_fk, variant_fk, script_fk, option) FROM '$$PATH$$/3920.dat';

--
-- Data for Name: meta_variant; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_variant (id, model_fk, name) FROM stdin;
\.
COPY lims.meta_variant (id, model_fk, name) FROM '$$PATH$$/3922.dat';

--
-- Data for Name: meta_variant_structure; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.meta_variant_structure (id, variant_fk, item_fk, attribute_fk, equipment_fk, unit_fk, status, "precision") FROM stdin;
\.
COPY lims.meta_variant_structure (id, variant_fk, item_fk, attribute_fk, equipment_fk, unit_fk, status, "precision") FROM '$$PATH$$/3924.dat';

--
-- Data for Name: mngt_department; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.mngt_department (id, name, parent_fk, group_fk, city_fk, address, phone, status) FROM stdin;
\.
COPY lims.mngt_department (id, name, parent_fk, group_fk, city_fk, address, phone, status) FROM '$$PATH$$/3926.dat';

--
-- Data for Name: mngt_material; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.mngt_material (id, num, name, note, unit_fk, inventory_fk, status) FROM stdin;
\.
COPY lims.mngt_material (id, num, name, note, unit_fk, inventory_fk, status) FROM '$$PATH$$/3928.dat';

--
-- Data for Name: mngt_post; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.mngt_post (id, name, parent_fk, group_fk) FROM stdin;
\.
COPY lims.mngt_post (id, name, parent_fk, group_fk) FROM '$$PATH$$/3930.dat';

--
-- Data for Name: mngt_work; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.mngt_work (id, name, note, decision_fk, status) FROM stdin;
\.
COPY lims.mngt_work (id, name, note, decision_fk, status) FROM '$$PATH$$/3932.dat';

--
-- Data for Name: mngt_worker; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.mngt_worker (id, first_name, last_name, middle_name, department_fk, post_fk, login, initials, status) FROM stdin;
\.
COPY lims.mngt_worker (id, first_name, last_name, middle_name, department_fk, post_fk, login, initials, status) FROM '$$PATH$$/3934.dat';

--
-- Data for Name: obj_collection; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.obj_collection (id, collection_fk, object_fk, order_num) FROM stdin;
\.
COPY lims.obj_collection (id, collection_fk, object_fk, order_num) FROM '$$PATH$$/3936.dat';

--
-- Data for Name: obj_entity; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.obj_entity (id, name, table_name) FROM stdin;
\.
COPY lims.obj_entity (id, name, table_name) FROM '$$PATH$$/3938.dat';

--
-- Data for Name: obj_main; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.obj_main (id, entity_fk, name) FROM stdin;
\.
COPY lims.obj_main (id, entity_fk, name) FROM '$$PATH$$/3940.dat';

--
-- Data for Name: obj_parent; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.obj_parent (id, object_fk, parent_fk, part) FROM stdin;
\.
COPY lims.obj_parent (id, object_fk, parent_fk, part) FROM '$$PATH$$/3942.dat';

--
-- Data for Name: prcs_plan; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.prcs_plan (id, object_fk, stage_fk, value, status) FROM stdin;
\.
COPY lims.prcs_plan (id, object_fk, stage_fk, value, status) FROM '$$PATH$$/3944.dat';

--
-- Data for Name: prcs_stage; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.prcs_stage (id, name, abbreviation, department_fk) FROM stdin;
\.
COPY lims.prcs_stage (id, name, abbreviation, department_fk) FROM '$$PATH$$/3946.dat';

--
-- Data for Name: prcs_stage_prerequisite; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.prcs_stage_prerequisite (id, stage_fk, prerequisite_fk) FROM stdin;
\.
COPY lims.prcs_stage_prerequisite (id, stage_fk, prerequisite_fk) FROM '$$PATH$$/3948.dat';

--
-- Data for Name: prcs_stage_sequence; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.prcs_stage_sequence (id, sequence_fk, stage_fk, order_num) FROM stdin;
\.
COPY lims.prcs_stage_sequence (id, sequence_fk, stage_fk, order_num) FROM '$$PATH$$/3950.dat';

--
-- Data for Name: prcs_task; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.prcs_task (id, plan_fk, stage_fk, object_fk, order_fk, deadline, priority, date_begin, date_end, status, script_fk, note) FROM stdin;
\.
COPY lims.prcs_task (id, plan_fk, stage_fk, object_fk, order_fk, deadline, priority, date_begin, date_end, status, script_fk, note) FROM '$$PATH$$/3952.dat';

--
-- Data for Name: result_main; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.result_main (id, task_fk, item_fk, attribute_fk, row_id, value_num, value_dict, value_date, value_str, unit_fk, apparatus_fk, status) FROM stdin;
\.
COPY lims.result_main (id, task_fk, item_fk, attribute_fk, row_id, value_num, value_dict, value_date, value_str, unit_fk, apparatus_fk, status) FROM '$$PATH$$/3954.dat';

--
-- Data for Name: result_material; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.result_material (id, task_fk, material_fk, volume, unit_fk) FROM stdin;
\.
COPY lims.result_material (id, task_fk, material_fk, volume, unit_fk) FROM '$$PATH$$/3957.dat';

--
-- Data for Name: result_work; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.result_work (id, task_fk, work_fk, volume, worker_fk) FROM stdin;
\.
COPY lims.result_work (id, task_fk, work_fk, volume, worker_fk) FROM '$$PATH$$/3959.dat';

--
-- Data for Name: tag_client; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tag_client (id, tag_fk, client_fk) FROM stdin;
\.
COPY lims.tag_client (id, tag_fk, client_fk) FROM '$$PATH$$/3890.dat';

--
-- Data for Name: tag_main; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tag_main (id, name, note, status, type) FROM stdin;
\.
COPY lims.tag_main (id, name, note, status, type) FROM '$$PATH$$/3961.dat';

--
-- Data for Name: tag_object; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tag_object (id, tag_fk, object_fk) FROM stdin;
\.
COPY lims.tag_object (id, tag_fk, object_fk) FROM '$$PATH$$/3882.dat';

--
-- Data for Name: tag_order; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tag_order (id, tag_fk, order_fk) FROM stdin;
\.
COPY lims.tag_order (id, tag_fk, order_fk) FROM '$$PATH$$/3886.dat';

--
-- Data for Name: tag_task; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tag_task (id, tag_fk, task_fk) FROM stdin;
\.
COPY lims.tag_task (id, tag_fk, task_fk) FROM '$$PATH$$/3876.dat';

--
-- Data for Name: tmpl_collection_entity; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_collection_entity (id, collection_fk, entity_fk) FROM stdin;
\.
COPY lims.tmpl_collection_entity (id, collection_fk, entity_fk) FROM '$$PATH$$/3963.dat';

--
-- Data for Name: tmpl_entity_parent; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_entity_parent (id, entity_fk, parent_fk) FROM stdin;
\.
COPY lims.tmpl_entity_parent (id, entity_fk, parent_fk) FROM '$$PATH$$/3965.dat';

--
-- Data for Name: tmpl_entity_stage; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_entity_stage (id, entity_fk, stage_fk) FROM stdin;
\.
COPY lims.tmpl_entity_stage (id, entity_fk, stage_fk) FROM '$$PATH$$/3967.dat';

--
-- Data for Name: tmpl_entity_tag; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_entity_tag (id, entity_fk, tag_fk) FROM stdin;
\.
COPY lims.tmpl_entity_tag (id, entity_fk, tag_fk) FROM '$$PATH$$/3969.dat';

--
-- Data for Name: tmpl_stage_decision; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_stage_decision (id, stage_fk, decision_fk) FROM stdin;
\.
COPY lims.tmpl_stage_decision (id, stage_fk, decision_fk) FROM '$$PATH$$/3971.dat';

--
-- Data for Name: tmpl_stage_inventory; Type: TABLE DATA; Schema: lims; Owner: postgres
--

COPY lims.tmpl_stage_inventory (id, stage_fk, inventory_fk) FROM stdin;
\.
COPY lims.tmpl_stage_inventory (id, stage_fk, inventory_fk) FROM '$$PATH$$/3973.dat';

--
-- Name: crm_client_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.crm_client_id_seq', 7, true);


--
-- Name: crm_material_price_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.crm_material_price_id_seq', 4, false);


--
-- Name: crm_order_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.crm_order_id_seq', 4, true);


--
-- Name: crm_work_price_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.crm_work_price_id_seq', 4, false);


--
-- Name: dict_city_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_city_id_seq', 4, false);


--
-- Name: dict_currency_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_currency_id_seq', 4, false);


--
-- Name: dict_decision_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_decision_id_seq', 4, false);


--
-- Name: dict_inventory_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_inventory_id_seq', 4, false);


--
-- Name: dict_main_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_main_id_seq', 11, true);


--
-- Name: dict_sequence_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_sequence_id_seq', 4, false);


--
-- Name: dict_unit_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.dict_unit_id_seq', 4, false);


--
-- Name: eqp_apparatus_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.eqp_apparatus_id_seq', 4, false);


--
-- Name: eqp_equipment_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.eqp_equipment_id_seq', 4, false);


--
-- Name: file_client_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.file_client_id_seq', 4, false);


--
-- Name: file_main_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.file_main_id_seq', 4, false);


--
-- Name: file_object_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.file_object_id_seq', 4, false);


--
-- Name: file_order_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.file_order_id_seq', 4, false);


--
-- Name: file_task_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.file_task_id_seq', 4, false);


--
-- Name: grant_worker_privilege_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.grant_worker_privilege_id_seq', 5, true);


--
-- Name: grant_worker_report_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.grant_worker_report_id_seq', 4, false);


--
-- Name: grant_worker_stage_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.grant_worker_stage_id_seq', 4, false);


--
-- Name: meta_attribute_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_attribute_id_seq', 4, false);


--
-- Name: meta_item_attribute_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_item_attribute_id_seq', 4, false);


--
-- Name: meta_item_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_item_id_seq', 4, false);


--
-- Name: meta_model_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_model_id_seq', 53, true);


--
-- Name: meta_model_item_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_model_item_id_seq', 4, false);


--
-- Name: meta_module_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_module_id_seq', 6, true);


--
-- Name: meta_module_privilege_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_module_privilege_id_seq', 9, true);


--
-- Name: meta_privilege_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_privilege_id_seq', 9, true);


--
-- Name: meta_report_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_report_id_seq', 13, false);


--
-- Name: meta_script_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_script_id_seq', 4, false);


--
-- Name: meta_solution_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_solution_id_seq', 4, false);


--
-- Name: meta_variant_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_variant_id_seq', 4, false);


--
-- Name: meta_variant_structure_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.meta_variant_structure_id_seq', 4, false);


--
-- Name: mngt_department_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.mngt_department_id_seq', 5, true);


--
-- Name: mngt_material_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.mngt_material_id_seq', 4, false);


--
-- Name: mngt_post_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.mngt_post_id_seq', 4, false);


--
-- Name: mngt_work_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.mngt_work_id_seq', 4, false);


--
-- Name: mngt_worker_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.mngt_worker_id_seq', 42, true);


--
-- Name: obj_collection_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.obj_collection_id_seq', 4, false);


--
-- Name: obj_entity_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.obj_entity_id_seq', 9, true);


--
-- Name: obj_main_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.obj_main_id_seq', 13, true);


--
-- Name: obj_parent_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.obj_parent_id_seq', 4, false);


--
-- Name: prcs_plan_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.prcs_plan_id_seq', 4, true);


--
-- Name: prcs_stage_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.prcs_stage_id_seq', 12, true);


--
-- Name: prcs_stage_prerequisite_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.prcs_stage_prerequisite_id_seq', 4, false);


--
-- Name: prcs_stage_sequence_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.prcs_stage_sequence_id_seq', 4, false);


--
-- Name: prcs_task_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.prcs_task_id_seq', 9, true);


--
-- Name: result_main_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.result_main_id_seq', 252, true);


--
-- Name: result_main_row_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.result_main_row_id_seq', 185, true);


--
-- Name: result_material_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.result_material_id_seq', 4, false);


--
-- Name: result_work_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.result_work_id_seq', 4, false);


--
-- Name: tag_client_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tag_client_id_seq', 4, false);


--
-- Name: tag_main_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tag_main_id_seq', 4, false);


--
-- Name: tag_object_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tag_object_id_seq', 4, false);


--
-- Name: tag_order_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tag_order_id_seq', 4, false);


--
-- Name: tag_task_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tag_task_id_seq', 4, false);


--
-- Name: tmpl_collection_entity_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_collection_entity_id_seq', 2, false);


--
-- Name: tmpl_entity_parent_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_entity_parent_id_seq', 4, false);


--
-- Name: tmpl_entity_stage_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_entity_stage_id_seq', 2, false);


--
-- Name: tmpl_entity_tag_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_entity_tag_id_seq', 2, false);


--
-- Name: tmpl_stage_decision_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_stage_decision_id_seq', 4, false);


--
-- Name: tmpl_stage_inventory_id_seq; Type: SEQUENCE SET; Schema: lims; Owner: postgres
--

SELECT pg_catalog.setval('lims.tmpl_stage_inventory_id_seq', 4, false);


--
-- Name: eqp_apparatus apparatus_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_apparatus
    ADD CONSTRAINT apparatus_pk PRIMARY KEY (id);


--
-- Name: eqp_apparatus apparatus_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_apparatus
    ADD CONSTRAINT apparatus_uk UNIQUE (equipment_fk, num);


--
-- Name: meta_attribute attribute_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_attribute
    ADD CONSTRAINT attribute_pk PRIMARY KEY (id);


--
-- Name: meta_attribute attribute_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_attribute
    ADD CONSTRAINT attribute_uk UNIQUE (name);


--
-- Name: dict_city city_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_city
    ADD CONSTRAINT city_pk PRIMARY KEY (id);


--
-- Name: dict_city city_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_city
    ADD CONSTRAINT city_uk UNIQUE (name);


--
-- Name: crm_client client_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_client
    ADD CONSTRAINT client_pk PRIMARY KEY (id);


--
-- Name: tmpl_collection_entity collection_entity_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_collection_entity
    ADD CONSTRAINT collection_entity_uk UNIQUE (collection_fk, entity_fk);


--
-- Name: obj_collection collection_order_num_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection
    ADD CONSTRAINT collection_order_num_uk UNIQUE (collection_fk, order_num);


--
-- Name: obj_collection collection_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection
    ADD CONSTRAINT collection_uk UNIQUE (collection_fk, object_fk);


--
-- Name: crm_company company_id_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_company
    ADD CONSTRAINT company_id_pk PRIMARY KEY (id_fk);


--
-- Name: crm_company company_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_company
    ADD CONSTRAINT company_uk UNIQUE (name);


--
-- Name: dict_currency currency_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_currency
    ADD CONSTRAINT currency_pk PRIMARY KEY (id);


--
-- Name: dict_currency currency_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_currency
    ADD CONSTRAINT currency_uk UNIQUE (name);


--
-- Name: mngt_department department_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department
    ADD CONSTRAINT department_pk PRIMARY KEY (id);


--
-- Name: mngt_department department_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department
    ADD CONSTRAINT department_uk UNIQUE (parent_fk, name);


--
-- Name: dict_decision dict_decision_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_decision
    ADD CONSTRAINT dict_decision_uk UNIQUE (parent_fk, name);


--
-- Name: dict_decision dict_inventory_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_decision
    ADD CONSTRAINT dict_inventory_copy1_pkey PRIMARY KEY (id);


--
-- Name: tag_main dict_work_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_main
    ADD CONSTRAINT dict_work_copy1_pkey PRIMARY KEY (id);


--
-- Name: dict_main dictionary_order_num_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_main
    ADD CONSTRAINT dictionary_order_num_uk UNIQUE (parent_fk, order_num);


--
-- Name: dict_main dictionary_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_main
    ADD CONSTRAINT dictionary_pk PRIMARY KEY (id);


--
-- Name: dict_main dictionary_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_main
    ADD CONSTRAINT dictionary_uk UNIQUE (parent_fk, name);


--
-- Name: tmpl_entity_parent entity_parent_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_parent
    ADD CONSTRAINT entity_parent_uk UNIQUE (parent_fk, entity_fk);


--
-- Name: obj_entity entity_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_entity
    ADD CONSTRAINT entity_pk PRIMARY KEY (id);


--
-- Name: tmpl_entity_stage entity_stage_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_stage
    ADD CONSTRAINT entity_stage_uk UNIQUE (entity_fk, stage_fk);


--
-- Name: obj_entity entity_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_entity
    ADD CONSTRAINT entity_uk UNIQUE (name);


--
-- Name: eqp_equipment equipment_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_equipment
    ADD CONSTRAINT equipment_pk PRIMARY KEY (id);


--
-- Name: eqp_equipment equipment_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_equipment
    ADD CONSTRAINT equipment_uk UNIQUE (group_fk, name);


--
-- Name: file_client file_client_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_client
    ADD CONSTRAINT file_client_uk UNIQUE (file_fk, client_fk);


--
-- Name: file_object file_object_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_object
    ADD CONSTRAINT file_object_uk UNIQUE (file_fk, object_fk);


--
-- Name: file_order file_order_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_order
    ADD CONSTRAINT file_order_uk UNIQUE (file_fk, order_fk);


--
-- Name: file_main file_reference_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_main
    ADD CONSTRAINT file_reference_pkey PRIMARY KEY (id);


--
-- Name: file_task file_task_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_task
    ADD CONSTRAINT file_task_uk UNIQUE (file_fk, task_fk);


--
-- Name: tmpl_stage_decision grant_stage_work_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_decision
    ADD CONSTRAINT grant_stage_work_copy1_pkey PRIMARY KEY (id);


--
-- Name: grant_worker_privilege grant_worker_report_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_privilege
    ADD CONSTRAINT grant_worker_report_copy1_pkey PRIMARY KEY (id);


--
-- Name: grant_worker_report grant_worker_report_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_report
    ADD CONSTRAINT grant_worker_report_pkey PRIMARY KEY (id);


--
-- Name: dict_inventory inventory_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_inventory
    ADD CONSTRAINT inventory_pk PRIMARY KEY (id);


--
-- Name: dict_inventory inventory_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_inventory
    ADD CONSTRAINT inventory_uk UNIQUE (parent_fk, name);


--
-- Name: meta_item_attribute item_attribute_order_num_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute
    ADD CONSTRAINT item_attribute_order_num_uk UNIQUE (item_fk, order_num);


--
-- Name: meta_item_attribute item_attribute_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute
    ADD CONSTRAINT item_attribute_uk UNIQUE (item_fk, attribute_fk);


--
-- Name: meta_item item_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item
    ADD CONSTRAINT item_uk UNIQUE (name);


--
-- Name: mngt_material material_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_material
    ADD CONSTRAINT material_pk PRIMARY KEY (id);


--
-- Name: crm_material_price material_price_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price
    ADD CONSTRAINT material_price_uk UNIQUE (material_fk, currency_fk, volume);


--
-- Name: mngt_material material_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_material
    ADD CONSTRAINT material_uk UNIQUE (num);


--
-- Name: meta_variant meta_model_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant
    ADD CONSTRAINT meta_model_copy1_pkey PRIMARY KEY (id);


--
-- Name: meta_module meta_model_copy1_pkey1; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module
    ADD CONSTRAINT meta_model_copy1_pkey1 PRIMARY KEY (id);


--
-- Name: meta_module_privilege meta_module_privilege_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module_privilege
    ADD CONSTRAINT meta_module_privilege_pkey PRIMARY KEY (id);


--
-- Name: meta_privilege meta_privilege_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_privilege
    ADD CONSTRAINT meta_privilege_pkey PRIMARY KEY (id);


--
-- Name: meta_report meta_report_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_report
    ADD CONSTRAINT meta_report_pkey PRIMARY KEY (id);


--
-- Name: meta_script meta_variant_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_script
    ADD CONSTRAINT meta_variant_copy1_pkey PRIMARY KEY (id);


--
-- Name: meta_variant_structure meta_variant_solution_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT meta_variant_solution_pkey PRIMARY KEY (id);


--
-- Name: meta_model_item model_item_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model_item
    ADD CONSTRAINT model_item_uk UNIQUE (model_fk, item_fk);


--
-- Name: meta_model model_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model
    ADD CONSTRAINT model_pk PRIMARY KEY (id);


--
-- Name: meta_model_item model_table_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model_item
    ADD CONSTRAINT model_table_pk PRIMARY KEY (id);


--
-- Name: meta_model model_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model
    ADD CONSTRAINT model_uk UNIQUE (name);


--
-- Name: meta_module_privilege module_privilege_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module_privilege
    ADD CONSTRAINT module_privilege_uk UNIQUE (module_fk, privilege_fk);


--
-- Name: meta_module module_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module
    ADD CONSTRAINT module_uk UNIQUE (name);


--
-- Name: obj_collection obj_parent_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection
    ADD CONSTRAINT obj_parent_copy1_pkey PRIMARY KEY (id);


--
-- Name: tmpl_entity_parent obj_parent_copy1_pkey1; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_parent
    ADD CONSTRAINT obj_parent_copy1_pkey1 PRIMARY KEY (id);


--
-- Name: obj_main object_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_main
    ADD CONSTRAINT object_pk PRIMARY KEY (id);


--
-- Name: crm_order order_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_order
    ADD CONSTRAINT order_pk PRIMARY KEY (id);


--
-- Name: obj_parent parent_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_parent
    ADD CONSTRAINT parent_pk PRIMARY KEY (id);


--
-- Name: obj_parent parent_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_parent
    ADD CONSTRAINT parent_uk UNIQUE (object_fk, parent_fk);


--
-- Name: crm_person person_id_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_person
    ADD CONSTRAINT person_id_pk PRIMARY KEY (id_fk);


--
-- Name: prcs_plan plan_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_plan
    ADD CONSTRAINT plan_uk UNIQUE (stage_fk, object_fk);


--
-- Name: mngt_post post_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_post
    ADD CONSTRAINT post_pk PRIMARY KEY (id);


--
-- Name: mngt_post post_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_post
    ADD CONSTRAINT post_uk UNIQUE (parent_fk, name);


--
-- Name: prcs_stage_sequence prcs_queue_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence
    ADD CONSTRAINT prcs_queue_pkey PRIMARY KEY (id);


--
-- Name: meta_solution prcs_solution_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT prcs_solution_uk UNIQUE (stage_fk, entity_fk, variant_fk, script_fk);


--
-- Name: prcs_stage_prerequisite prerequisite_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_prerequisite
    ADD CONSTRAINT prerequisite_pk PRIMARY KEY (id);


--
-- Name: crm_material_price price_material_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price
    ADD CONSTRAINT price_material_pk PRIMARY KEY (id);


--
-- Name: crm_work_price price_solution_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_work_price
    ADD CONSTRAINT price_solution_pk PRIMARY KEY (id);


--
-- Name: meta_privilege privilege_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_privilege
    ADD CONSTRAINT privilege_uk UNIQUE (name);


--
-- Name: prcs_plan queue_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_plan
    ADD CONSTRAINT queue_pk PRIMARY KEY (id);


--
-- Name: file_main reference_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_main
    ADD CONSTRAINT reference_uk UNIQUE (md5);


--
-- Name: meta_report report_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_report
    ADD CONSTRAINT report_uk UNIQUE (group_fk, name);


--
-- Name: result_material result_material_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material
    ADD CONSTRAINT result_material_pk PRIMARY KEY (id);


--
-- Name: result_material result_material_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material
    ADD CONSTRAINT result_material_uk UNIQUE (task_fk, material_fk);


--
-- Name: result_main result_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_pk PRIMARY KEY (id);


--
-- Name: result_work result_solution_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work
    ADD CONSTRAINT result_solution_pk PRIMARY KEY (id);


--
-- Name: result_main result_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_uk UNIQUE (task_fk, item_fk, attribute_fk, row_id);


--
-- Name: result_work result_work_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work
    ADD CONSTRAINT result_work_uk UNIQUE (task_fk, work_fk, worker_fk);


--
-- Name: meta_script script_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_script
    ADD CONSTRAINT script_uk UNIQUE (model_fk, name, version);


--
-- Name: dict_sequence sequence_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_sequence
    ADD CONSTRAINT sequence_pk PRIMARY KEY (id);


--
-- Name: dict_sequence sequence_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_sequence
    ADD CONSTRAINT sequence_uk UNIQUE (department_fk, name);


--
-- Name: tmpl_stage_decision stage_decision_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_decision
    ADD CONSTRAINT stage_decision_uk UNIQUE (stage_fk, decision_fk);


--
-- Name: tmpl_stage_inventory stage_inventory_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_inventory
    ADD CONSTRAINT stage_inventory_uk UNIQUE (stage_fk, inventory_fk);


--
-- Name: prcs_stage stage_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage
    ADD CONSTRAINT stage_pk PRIMARY KEY (id);


--
-- Name: prcs_stage_prerequisite stage_prerequisite_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_prerequisite
    ADD CONSTRAINT stage_prerequisite_uk UNIQUE (stage_fk, prerequisite_fk);


--
-- Name: prcs_stage_sequence stage_sequence_order_num_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence
    ADD CONSTRAINT stage_sequence_order_num_uk UNIQUE (sequence_fk, order_num);


--
-- Name: prcs_stage_sequence stage_sequence_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence
    ADD CONSTRAINT stage_sequence_uk UNIQUE (sequence_fk, stage_fk);


--
-- Name: prcs_stage stage_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage
    ADD CONSTRAINT stage_uk UNIQUE (department_fk, name);


--
-- Name: meta_item_attribute table_attribute_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute
    ADD CONSTRAINT table_attribute_pk PRIMARY KEY (id);


--
-- Name: meta_item table_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item
    ADD CONSTRAINT table_pk PRIMARY KEY (id);


--
-- Name: file_client tag_client_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_client
    ADD CONSTRAINT tag_client_copy1_pkey PRIMARY KEY (id);


--
-- Name: tag_client tag_client_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_client
    ADD CONSTRAINT tag_client_uk UNIQUE (tag_fk, client_fk);


--
-- Name: tag_client tag_object_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_client
    ADD CONSTRAINT tag_object_copy1_pkey PRIMARY KEY (id);


--
-- Name: file_object tag_object_copy1_pkey1; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_object
    ADD CONSTRAINT tag_object_copy1_pkey1 PRIMARY KEY (id);


--
-- Name: tag_object tag_object_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_object
    ADD CONSTRAINT tag_object_pkey PRIMARY KEY (id);


--
-- Name: tag_object tag_object_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_object
    ADD CONSTRAINT tag_object_uk UNIQUE (tag_fk, object_fk);


--
-- Name: file_order tag_order_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_order
    ADD CONSTRAINT tag_order_copy1_pkey PRIMARY KEY (id);


--
-- Name: tag_order tag_order_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_order
    ADD CONSTRAINT tag_order_uk UNIQUE (tag_fk, order_fk);


--
-- Name: tag_task tag_task_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_task
    ADD CONSTRAINT tag_task_copy1_pkey PRIMARY KEY (id);


--
-- Name: tag_order tag_task_copy1_pkey1; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_order
    ADD CONSTRAINT tag_task_copy1_pkey1 PRIMARY KEY (id);


--
-- Name: file_task tag_task_copy1_pkey2; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_task
    ADD CONSTRAINT tag_task_copy1_pkey2 PRIMARY KEY (id);


--
-- Name: tag_task tag_task_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_task
    ADD CONSTRAINT tag_task_uk UNIQUE (tag_fk, task_fk);


--
-- Name: prcs_task task_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_pk PRIMARY KEY (id);


--
-- Name: tmpl_entity_tag tmpl_collection_entity_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_tag
    ADD CONSTRAINT tmpl_collection_entity_copy1_pkey PRIMARY KEY (id);


--
-- Name: tmpl_collection_entity tmpl_entity_parent_copy1_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_collection_entity
    ADD CONSTRAINT tmpl_entity_parent_copy1_pkey PRIMARY KEY (id);


--
-- Name: tmpl_entity_stage tmpl_entity_stage_pkey; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_stage
    ADD CONSTRAINT tmpl_entity_stage_pkey PRIMARY KEY (id);


--
-- Name: tmpl_entity_tag tmpl_entity_tag_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_tag
    ADD CONSTRAINT tmpl_entity_tag_uk UNIQUE (entity_fk, tag_fk);


--
-- Name: dict_unit unit_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_unit
    ADD CONSTRAINT unit_pk PRIMARY KEY (id);


--
-- Name: dict_unit unit_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_unit
    ADD CONSTRAINT unit_uk UNIQUE (symbol);


--
-- Name: meta_variant variant_model_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant
    ADD CONSTRAINT variant_model_uk UNIQUE (model_fk, name);


--
-- Name: meta_variant_structure variant_structure_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_uk UNIQUE (variant_fk, item_fk, attribute_fk);


--
-- Name: tmpl_stage_inventory work_inventory_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_inventory
    ADD CONSTRAINT work_inventory_pk PRIMARY KEY (id);


--
-- Name: mngt_work work_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_work
    ADD CONSTRAINT work_pk PRIMARY KEY (id);


--
-- Name: crm_work_price work_price_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_work_price
    ADD CONSTRAINT work_price_uk UNIQUE (price, work_fk, volume);


--
-- Name: meta_solution work_solution_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT work_solution_pk PRIMARY KEY (id);


--
-- Name: mngt_work work_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_work
    ADD CONSTRAINT work_uk UNIQUE (name);


--
-- Name: grant_worker_stage work_worker_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_stage
    ADD CONSTRAINT work_worker_pk PRIMARY KEY (id);


--
-- Name: mngt_worker worker_pk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_worker
    ADD CONSTRAINT worker_pk PRIMARY KEY (id);


--
-- Name: grant_worker_privilege worker_privilege_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_privilege
    ADD CONSTRAINT worker_privilege_uk UNIQUE (worker_fk, module_privilege_fk);


--
-- Name: grant_worker_report worker_report_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_report
    ADD CONSTRAINT worker_report_uk UNIQUE (worker_fk, report_fk);


--
-- Name: grant_worker_stage worker_stage_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_stage
    ADD CONSTRAINT worker_stage_uk UNIQUE (worker_fk, stage_fk);


--
-- Name: mngt_worker worker_uk; Type: CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_worker
    ADD CONSTRAINT worker_uk UNIQUE (login);


--
-- Name: eqp_apparatus apparatus_department_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_apparatus
    ADD CONSTRAINT apparatus_department_fk FOREIGN KEY (department_fk) REFERENCES lims.mngt_department(id) MATCH FULL;


--
-- Name: eqp_apparatus apparatus_equipment_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_apparatus
    ADD CONSTRAINT apparatus_equipment_fk FOREIGN KEY (equipment_fk) REFERENCES lims.eqp_equipment(id) MATCH FULL;


--
-- Name: crm_client client_city_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_client
    ADD CONSTRAINT client_city_fk FOREIGN KEY (city_fk) REFERENCES lims.dict_city(id) MATCH FULL;


--
-- Name: obj_collection collection_collection_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection
    ADD CONSTRAINT collection_collection_fk FOREIGN KEY (collection_fk) REFERENCES lims.obj_main(id) MATCH FULL;


--
-- Name: tmpl_collection_entity collection_entity_collection_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_collection_entity
    ADD CONSTRAINT collection_entity_collection_fk FOREIGN KEY (collection_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: tmpl_collection_entity collection_entity_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_collection_entity
    ADD CONSTRAINT collection_entity_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: obj_collection collection_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_collection
    ADD CONSTRAINT collection_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id) MATCH FULL;


--
-- Name: crm_company company_id_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_company
    ADD CONSTRAINT company_id_fk FOREIGN KEY (id_fk) REFERENCES lims.crm_client(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mngt_department department_city_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department
    ADD CONSTRAINT department_city_fk FOREIGN KEY (city_fk) REFERENCES lims.dict_city(id) MATCH FULL;


--
-- Name: mngt_department department_group_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department
    ADD CONSTRAINT department_group_fk FOREIGN KEY (group_fk) REFERENCES lims.dict_main(id) MATCH FULL;


--
-- Name: mngt_department department_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_department
    ADD CONSTRAINT department_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.mngt_department(id) MATCH FULL;


--
-- Name: dict_decision dict_decision_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_decision
    ADD CONSTRAINT dict_decision_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.dict_decision(id) MATCH FULL;


--
-- Name: dict_main dictionary_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_main
    ADD CONSTRAINT dictionary_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.dict_main(id) MATCH FULL;


--
-- Name: tmpl_entity_parent entity_parent_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_parent
    ADD CONSTRAINT entity_parent_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: tmpl_entity_parent entity_parent_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_parent
    ADD CONSTRAINT entity_parent_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: tmpl_entity_stage entity_stage_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_stage
    ADD CONSTRAINT entity_stage_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id);


--
-- Name: tmpl_entity_stage entity_stage_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_stage
    ADD CONSTRAINT entity_stage_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id);


--
-- Name: eqp_equipment equipment_group_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.eqp_equipment
    ADD CONSTRAINT equipment_group_fk FOREIGN KEY (group_fk) REFERENCES lims.dict_main(id) MATCH FULL;


--
-- Name: file_client file_client_client_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_client
    ADD CONSTRAINT file_client_client_fk FOREIGN KEY (client_fk) REFERENCES lims.crm_client(id);


--
-- Name: file_client file_client_file_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_client
    ADD CONSTRAINT file_client_file_fk FOREIGN KEY (file_fk) REFERENCES lims.file_main(id);


--
-- Name: file_object file_object_file_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_object
    ADD CONSTRAINT file_object_file_fk FOREIGN KEY (file_fk) REFERENCES lims.file_main(id);


--
-- Name: file_object file_object_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_object
    ADD CONSTRAINT file_object_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id);


--
-- Name: file_order file_order_file_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_order
    ADD CONSTRAINT file_order_file_fk FOREIGN KEY (file_fk) REFERENCES lims.file_main(id);


--
-- Name: file_order file_order_order_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_order
    ADD CONSTRAINT file_order_order_fk FOREIGN KEY (order_fk) REFERENCES lims.crm_order(id);


--
-- Name: file_task file_task_file_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_task
    ADD CONSTRAINT file_task_file_fk FOREIGN KEY (file_fk) REFERENCES lims.file_main(id);


--
-- Name: file_task file_task_task_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_task
    ADD CONSTRAINT file_task_task_fk FOREIGN KEY (task_fk) REFERENCES lims.prcs_task(id);


--
-- Name: dict_inventory inventory_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_inventory
    ADD CONSTRAINT inventory_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.dict_inventory(id) MATCH FULL;


--
-- Name: meta_item_attribute item_attribute_attribute_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute
    ADD CONSTRAINT item_attribute_attribute_fk FOREIGN KEY (attribute_fk) REFERENCES lims.meta_attribute(id) MATCH FULL;


--
-- Name: meta_item_attribute item_attribute_item_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item_attribute
    ADD CONSTRAINT item_attribute_item_fk FOREIGN KEY (item_fk) REFERENCES lims.meta_item(id) MATCH FULL;


--
-- Name: meta_item item_order_attribute_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_item
    ADD CONSTRAINT item_order_attribute_fk FOREIGN KEY (order_attribute_fk) REFERENCES lims.meta_attribute(id) MATCH FULL;


--
-- Name: mngt_material material_inventory_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_material
    ADD CONSTRAINT material_inventory_fk FOREIGN KEY (inventory_fk) REFERENCES lims.dict_inventory(id) MATCH FULL;


--
-- Name: crm_material_price material_price_currency_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price
    ADD CONSTRAINT material_price_currency_fk FOREIGN KEY (currency_fk) REFERENCES lims.dict_currency(id) MATCH FULL;


--
-- Name: crm_material_price material_price_material_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price
    ADD CONSTRAINT material_price_material_fk FOREIGN KEY (material_fk) REFERENCES lims.mngt_material(id) MATCH FULL;


--
-- Name: crm_material_price material_price_unit_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_material_price
    ADD CONSTRAINT material_price_unit_fk FOREIGN KEY (unit_fk) REFERENCES lims.dict_unit(id) MATCH FULL;


--
-- Name: mngt_material material_unit_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_material
    ADD CONSTRAINT material_unit_fk FOREIGN KEY (unit_fk) REFERENCES lims.dict_unit(id) MATCH FULL;


--
-- Name: meta_model_item model_item_item_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model_item
    ADD CONSTRAINT model_item_item_fk FOREIGN KEY (item_fk) REFERENCES lims.meta_item(id) MATCH FULL;


--
-- Name: meta_model_item model_item_model_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_model_item
    ADD CONSTRAINT model_item_model_fk FOREIGN KEY (model_fk) REFERENCES lims.meta_model(id) MATCH FULL;


--
-- Name: meta_module_privilege module_privilege_module_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module_privilege
    ADD CONSTRAINT module_privilege_module_fk FOREIGN KEY (module_fk) REFERENCES lims.meta_module(id);


--
-- Name: meta_module_privilege module_privilege_privilege_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_module_privilege
    ADD CONSTRAINT module_privilege_privilege_fk FOREIGN KEY (privilege_fk) REFERENCES lims.meta_privilege(id);


--
-- Name: obj_main object_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_main
    ADD CONSTRAINT object_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: crm_order order_client_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_order
    ADD CONSTRAINT order_client_fk FOREIGN KEY (client_fk) REFERENCES lims.crm_client(id) MATCH FULL;


--
-- Name: crm_order order_manager_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_order
    ADD CONSTRAINT order_manager_fk FOREIGN KEY (manager_fk) REFERENCES lims.mngt_worker(id) MATCH FULL;


--
-- Name: obj_parent parent_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_parent
    ADD CONSTRAINT parent_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id) MATCH FULL;


--
-- Name: obj_parent parent_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.obj_parent
    ADD CONSTRAINT parent_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.obj_main(id) MATCH FULL;


--
-- Name: crm_person person_id_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_person
    ADD CONSTRAINT person_id_fk FOREIGN KEY (id_fk) REFERENCES lims.crm_client(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prcs_plan plan_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_plan
    ADD CONSTRAINT plan_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prcs_plan plan_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_plan
    ADD CONSTRAINT plan_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mngt_post post_group_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_post
    ADD CONSTRAINT post_group_fk FOREIGN KEY (group_fk) REFERENCES lims.dict_main(id) MATCH FULL;


--
-- Name: mngt_post post_parent_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_post
    ADD CONSTRAINT post_parent_fk FOREIGN KEY (parent_fk) REFERENCES lims.mngt_post(id) MATCH FULL;


--
-- Name: meta_solution prcs_solution_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT prcs_solution_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: meta_solution prcs_solution_script_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT prcs_solution_script_fk FOREIGN KEY (script_fk) REFERENCES lims.meta_script(id);


--
-- Name: meta_solution prcs_solution_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT prcs_solution_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: meta_solution prcs_solution_variant_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_solution
    ADD CONSTRAINT prcs_solution_variant_fk FOREIGN KEY (variant_fk) REFERENCES lims.meta_variant(id);


--
-- Name: file_main reference_group_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.file_main
    ADD CONSTRAINT reference_group_fk FOREIGN KEY (group_fk) REFERENCES lims.dict_main(id);


--
-- Name: meta_report report_group_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_report
    ADD CONSTRAINT report_group_fk FOREIGN KEY (group_fk) REFERENCES lims.dict_main(id);


--
-- Name: result_main result_apparatus_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_apparatus_fk FOREIGN KEY (apparatus_fk) REFERENCES lims.eqp_apparatus(id);


--
-- Name: result_main result_attribute_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_attribute_fk FOREIGN KEY (attribute_fk) REFERENCES lims.meta_attribute(id) MATCH FULL;


--
-- Name: result_main result_item_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_item_fk FOREIGN KEY (item_fk) REFERENCES lims.meta_item(id) MATCH FULL;


--
-- Name: result_material result_material_material_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material
    ADD CONSTRAINT result_material_material_fk FOREIGN KEY (material_fk) REFERENCES lims.mngt_material(id) MATCH FULL;


--
-- Name: result_material result_material_task_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material
    ADD CONSTRAINT result_material_task_fk FOREIGN KEY (task_fk) REFERENCES lims.prcs_task(id) MATCH FULL;


--
-- Name: result_material result_material_unit_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_material
    ADD CONSTRAINT result_material_unit_fk FOREIGN KEY (unit_fk) REFERENCES lims.dict_unit(id) MATCH FULL;


--
-- Name: result_main result_task_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_task_fk FOREIGN KEY (task_fk) REFERENCES lims.prcs_task(id) MATCH FULL;


--
-- Name: result_main result_unit_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_unit_fk FOREIGN KEY (unit_fk) REFERENCES lims.dict_unit(id) MATCH FULL;


--
-- Name: result_main result_value_dict_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_main
    ADD CONSTRAINT result_value_dict_fk FOREIGN KEY (value_dict) REFERENCES lims.dict_main(id) MATCH FULL;


--
-- Name: result_work result_work_task_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work
    ADD CONSTRAINT result_work_task_fk FOREIGN KEY (task_fk) REFERENCES lims.prcs_task(id) MATCH FULL;


--
-- Name: result_work result_work_work_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work
    ADD CONSTRAINT result_work_work_fk FOREIGN KEY (work_fk) REFERENCES lims.mngt_work(id) MATCH FULL;


--
-- Name: result_work result_work_worker_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.result_work
    ADD CONSTRAINT result_work_worker_fk FOREIGN KEY (worker_fk) REFERENCES lims.mngt_worker(id);


--
-- Name: meta_script script_model_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_script
    ADD CONSTRAINT script_model_fk FOREIGN KEY (model_fk) REFERENCES lims.meta_model(id);


--
-- Name: dict_sequence sequence_department_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.dict_sequence
    ADD CONSTRAINT sequence_department_fk FOREIGN KEY (department_fk) REFERENCES lims.mngt_department(id);


--
-- Name: tmpl_stage_decision stage_decision_decision_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_decision
    ADD CONSTRAINT stage_decision_decision_fk FOREIGN KEY (decision_fk) REFERENCES lims.dict_decision(id) MATCH FULL;


--
-- Name: tmpl_stage_decision stage_decision_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_decision
    ADD CONSTRAINT stage_decision_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: prcs_stage stage_department_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage
    ADD CONSTRAINT stage_department_fk FOREIGN KEY (department_fk) REFERENCES lims.mngt_department(id);


--
-- Name: tmpl_stage_inventory stage_inventory_inventory_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_inventory
    ADD CONSTRAINT stage_inventory_inventory_fk FOREIGN KEY (inventory_fk) REFERENCES lims.dict_inventory(id) MATCH FULL;


--
-- Name: tmpl_stage_inventory stage_inventory_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_stage_inventory
    ADD CONSTRAINT stage_inventory_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: prcs_stage_prerequisite stage_prerequisite_prerequisite_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_prerequisite
    ADD CONSTRAINT stage_prerequisite_prerequisite_fk FOREIGN KEY (prerequisite_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: prcs_stage_prerequisite stage_prerequisite_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_prerequisite
    ADD CONSTRAINT stage_prerequisite_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: prcs_stage_sequence stage_sequence_sequence_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence
    ADD CONSTRAINT stage_sequence_sequence_fk FOREIGN KEY (sequence_fk) REFERENCES lims.dict_sequence(id);


--
-- Name: prcs_stage_sequence stage_sequence_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_stage_sequence
    ADD CONSTRAINT stage_sequence_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id);


--
-- Name: tag_client tag_client_client_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_client
    ADD CONSTRAINT tag_client_client_fk FOREIGN KEY (client_fk) REFERENCES lims.crm_client(id);


--
-- Name: tag_client tag_client_tag_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_client
    ADD CONSTRAINT tag_client_tag_fk FOREIGN KEY (tag_fk) REFERENCES lims.tag_main(id);


--
-- Name: tag_object tag_object_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_object
    ADD CONSTRAINT tag_object_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id);


--
-- Name: tag_object tag_object_tag_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_object
    ADD CONSTRAINT tag_object_tag_fk FOREIGN KEY (tag_fk) REFERENCES lims.tag_main(id);


--
-- Name: tag_order tag_order_order_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_order
    ADD CONSTRAINT tag_order_order_fk FOREIGN KEY (order_fk) REFERENCES lims.crm_order(id);


--
-- Name: tag_order tag_order_tag_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_order
    ADD CONSTRAINT tag_order_tag_fk FOREIGN KEY (tag_fk) REFERENCES lims.tag_main(id);


--
-- Name: tag_task tag_task_tag_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_task
    ADD CONSTRAINT tag_task_tag_fk FOREIGN KEY (tag_fk) REFERENCES lims.tag_main(id);


--
-- Name: tag_task tag_task_task_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tag_task
    ADD CONSTRAINT tag_task_task_fk FOREIGN KEY (task_fk) REFERENCES lims.prcs_task(id);


--
-- Name: prcs_task task_object_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_object_fk FOREIGN KEY (object_fk) REFERENCES lims.obj_main(id);


--
-- Name: prcs_task task_order_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_order_fk FOREIGN KEY (order_fk) REFERENCES lims.crm_order(id);


--
-- Name: prcs_task task_plan_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_plan_fk FOREIGN KEY (plan_fk) REFERENCES lims.prcs_plan(id) MATCH FULL;


--
-- Name: prcs_task task_script_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_script_fk FOREIGN KEY (script_fk) REFERENCES lims.meta_script(id);


--
-- Name: prcs_task task_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.prcs_task
    ADD CONSTRAINT task_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id);


--
-- Name: tmpl_entity_tag tmpl_entity_entity_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_tag
    ADD CONSTRAINT tmpl_entity_entity_fk FOREIGN KEY (entity_fk) REFERENCES lims.obj_entity(id) MATCH FULL;


--
-- Name: tmpl_entity_tag tmpl_entity_tag_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.tmpl_entity_tag
    ADD CONSTRAINT tmpl_entity_tag_fk FOREIGN KEY (tag_fk) REFERENCES lims.tag_main(id) MATCH FULL;


--
-- Name: meta_variant variant_model_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant
    ADD CONSTRAINT variant_model_fk FOREIGN KEY (model_fk) REFERENCES lims.meta_model(id);


--
-- Name: meta_variant_structure variant_structure_attribute_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_attribute_fk FOREIGN KEY (attribute_fk) REFERENCES lims.meta_attribute(id);


--
-- Name: meta_variant_structure variant_structure_equipment_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_equipment_fk FOREIGN KEY (equipment_fk) REFERENCES lims.eqp_equipment(id);


--
-- Name: meta_variant_structure variant_structure_item_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_item_fk FOREIGN KEY (item_fk) REFERENCES lims.meta_item(id);


--
-- Name: meta_variant_structure variant_structure_unit_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_unit_fk FOREIGN KEY (unit_fk) REFERENCES lims.dict_unit(id);


--
-- Name: meta_variant_structure variant_structure_variant_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.meta_variant_structure
    ADD CONSTRAINT variant_structure_variant_fk FOREIGN KEY (variant_fk) REFERENCES lims.meta_variant(id);


--
-- Name: mngt_work work_decision_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_work
    ADD CONSTRAINT work_decision_fk FOREIGN KEY (decision_fk) REFERENCES lims.dict_decision(id);


--
-- Name: crm_work_price work_price_currency_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_work_price
    ADD CONSTRAINT work_price_currency_fk FOREIGN KEY (currency_fk) REFERENCES lims.dict_currency(id) MATCH FULL;


--
-- Name: crm_work_price work_price_work_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.crm_work_price
    ADD CONSTRAINT work_price_work_fk FOREIGN KEY (work_fk) REFERENCES lims.mngt_work(id) MATCH FULL;


--
-- Name: mngt_worker worker_department_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_worker
    ADD CONSTRAINT worker_department_fk FOREIGN KEY (department_fk) REFERENCES lims.mngt_department(id) MATCH FULL;


--
-- Name: mngt_worker worker_post_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.mngt_worker
    ADD CONSTRAINT worker_post_fk FOREIGN KEY (post_fk) REFERENCES lims.mngt_post(id) MATCH FULL;


--
-- Name: grant_worker_privilege worker_privilege_module_privilege_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_privilege
    ADD CONSTRAINT worker_privilege_module_privilege_fk FOREIGN KEY (module_privilege_fk) REFERENCES lims.meta_module_privilege(id);


--
-- Name: grant_worker_privilege worker_privilege_worker_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_privilege
    ADD CONSTRAINT worker_privilege_worker_fk FOREIGN KEY (worker_fk) REFERENCES lims.mngt_worker(id);


--
-- Name: grant_worker_report worker_report_report_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_report
    ADD CONSTRAINT worker_report_report_fk FOREIGN KEY (report_fk) REFERENCES lims.meta_report(id);


--
-- Name: grant_worker_report worker_report_worker_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_report
    ADD CONSTRAINT worker_report_worker_fk FOREIGN KEY (worker_fk) REFERENCES lims.mngt_worker(id);


--
-- Name: grant_worker_stage worker_stage_stage_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_stage
    ADD CONSTRAINT worker_stage_stage_fk FOREIGN KEY (stage_fk) REFERENCES lims.prcs_stage(id) MATCH FULL;


--
-- Name: grant_worker_stage worker_stage_worker_fk; Type: FK CONSTRAINT; Schema: lims; Owner: postgres
--

ALTER TABLE ONLY lims.grant_worker_stage
    ADD CONSTRAINT worker_stage_worker_fk FOREIGN KEY (worker_fk) REFERENCES lims.mngt_worker(id) MATCH FULL;


--
-- PostgreSQL database dump complete
--

